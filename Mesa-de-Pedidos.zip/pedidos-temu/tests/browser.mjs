import assert from 'node:assert/strict'
import {createServer} from 'node:http'
import {spawn} from 'node:child_process'
import {readFile} from 'node:fs/promises'
import {chromium,devices} from 'playwright-core'
import {PGlite} from '@electric-sql/pglite'

const db=new PGlite()
const buyer='10000000-0000-4000-8000-000000000001'
const orders='10000000-0000-4000-8000-000000000002'
const migration=await readFile(new URL('../supabase/migrations/202611130001_orders.sql',import.meta.url),'utf8')
await db.exec(`create role anon;create role authenticated;create schema auth;create schema storage;create table auth.users(id uuid primary key);
create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
create table storage.buckets(id text primary key,name text,public boolean,file_size_limit int,allowed_mime_types text[]);
create table storage.objects(id uuid default gen_random_uuid(),bucket_id text,name text);
alter table storage.objects enable row level security;grant usage on schema auth,storage to authenticated;`)
await db.exec(migration)
await db.query('insert into auth.users values($1),($2)',[buyer,orders])
await db.query("insert into public.staff values($1,'compras'),($2,'pedidos')",[buyer,orders])
const base='http://127.0.0.1:4187'
const endpoint='http://127.0.0.1:4188'
const api=createServer(async(req,res)=>{
  const url=new URL(req.url,endpoint)
  const token=req.headers.authorization?.slice(7)
  const headers={'content-type':'application/json','access-control-allow-origin':base,'access-control-allow-headers':'*','access-control-allow-methods':'GET,POST,OPTIONS'}
  const send=(data,status=200)=>{res.writeHead(status,headers);res.end(JSON.stringify(data))}
  if(req.method==='OPTIONS'){res.writeHead(204,headers);res.end();return}
  try {
    const chunks=[]
    for await(const chunk of req)chunks.push(chunk)
    const body=chunks.length?JSON.parse(Buffer.concat(chunks).toString()):{}
    if(url.pathname==='/auth/v1/token'){
      const uid=body.email==='compras@example.test'?buyer:orders
      const access_token='eyJhbGciOiJIUzI1NiJ9.'+Buffer.from(JSON.stringify({sub:uid,exp:Math.floor(Date.now()/1000)+3600})).toString('base64url')+'.YQ'
      return send({access_token,expires_in:3600,refresh_token:uid,token_type:'bearer',user:{id:uid,email:body.email,app_metadata:{},user_metadata:{},aud:'authenticated',created_at:new Date().toISOString()}})
    }
    const uid=JSON.parse(Buffer.from(token.split('.')[1],'base64url').toString()).sub
    const result=await db.transaction(async tx=>{
      await tx.exec('set local role authenticated')
      await tx.query("select set_config('request.jwt.claim.sub',$1,true)",[uid])
      if(url.pathname.endsWith('/rpc/staff_role'))return (await tx.query('select public.staff_role() role')).rows[0].role
      if(url.pathname.endsWith('/rpc/apply_operations')){await tx.query('select public.apply_operations($1)',[JSON.stringify(body.ops)]);return null}
      if(url.pathname.endsWith('/records'))return (await tx.query('select * from public.records order by id')).rows
      if(url.pathname.endsWith('/activity'))return (await tx.query('select * from public.activity order by id desc')).rows
      throw new Error('Ruta de prueba desconocida: '+url.pathname)
    })
    send(result)
  }catch(error){send({message:error.message,code:error.code??'TEST'},400)}
})
await new Promise(resolve=>api.listen(4188,'127.0.0.1',resolve))
const build=spawn(process.execPath,['node_modules/vite/bin/vite.js','build','--outDir','dist-browser'],{env:{...process.env,VITE_SUPABASE_URL:endpoint,VITE_SUPABASE_PUBLISHABLE_KEY:'local-test-key'},stdio:'ignore'})
assert.equal(await new Promise(resolve=>build.on('exit',resolve)),0)
const server=spawn(process.execPath,['node_modules/vite/bin/vite.js','preview','--outDir','dist-browser','--host','127.0.0.1','--port','4187','--strictPort'],{stdio:'ignore'})
let browser
try {
  browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH??'/usr/bin/chromium',headless:true})
  for(let i=0;i<80;i++){
    try{if((await fetch(base)).ok)break}catch{}
    await new Promise(resolve=>setTimeout(resolve,100))
  }
  const tablet=await browser.newContext({...devices['Pixel 7'],permissions:['clipboard-read','clipboard-write']})
  const desktop=await browser.newContext()
  const ordersPage=await tablet.newPage(), buyerPage=await desktop.newPage()
  const errors=[]
  for(const page of [ordersPage,buyerPage])page.on('pageerror',e=>errors.push(e.message))
  async function login(page,email){
    await page.goto(base)
    await page.getByLabel('Correo electrónico').fill(email)
    await page.getByLabel('Contraseña').fill('prueba-2026')
    await page.getByRole('button',{name:'Entrar',exact:true}).click()
    await page.getByRole('heading',{name:'Panel de pedidos'}).waitFor()
    await page.evaluate(()=>navigator.serviceWorker.ready)
  }
  await login(ordersPage,'pedidos@example.test')
  await login(buyerPage,'compras@example.test')
  await tablet.setOffline(true)
  await ordersPage.reload()
  await ordersPage.getByRole('button',{name:'Nuevo artículo',exact:true}).click()
  await ordersPage.getByRole('button',{name:'Crear cliente aquí'}).click()
  await ordersPage.getByLabel('Nombre del nuevo cliente').fill('María')
  await ordersPage.getByLabel('Enlace original de Temu').fill('https://share.temu.com/test')
  await ordersPage.getByLabel('Nombre del producto').fill('Camiseta de flores')
  await ordersPage.getByLabel('Cantidad',{exact:true}).fill('2')
  await ordersPage.getByRole('button',{name:'Talla',exact:true}).click()
  await ordersPage.getByLabel('Valor de Talla').fill('M')
  await ordersPage.getByRole('button',{name:'Guardar artículo'}).click()
  await ordersPage.getByRole('dialog').waitFor({state:'hidden'})
  await ordersPage.getByRole('button',{name:/Camiseta de flores/}).waitFor()
  assert.equal((await db.query('select count(*)::int n from public.records')).rows[0].n,0)
  await tablet.setOffline(false)
  await ordersPage.getByRole('button',{name:'Sincronizar ahora'}).click()
  await ordersPage.getByText('Sincronizado',{exact:true}).waitFor({state:'attached'})
  await buyerPage.getByRole('button',{name:'Sincronizar ahora'}).click()
  await buyerPage.getByRole('button',{name:'Preparar compra',exact:true}).click()
  await buyerPage.getByRole('heading',{name:'Camiseta de flores'}).waitFor()
  buyerPage.once('dialog',dialog=>dialog.accept())
  await buyerPage.getByRole('button',{name:'Marcar comprado'}).click()
  await buyerPage.getByRole('button',{name:'Cobros',exact:true}).click()
  await buyerPage.getByRole('button',{name:'Establecer precio'}).click()
  await buyerPage.getByLabel('Costo real unitario').fill('7.50')
  await buyerPage.getByRole('button',{name:'Publicar precio'}).click()
  await buyerPage.getByText(/\$8\.50 por unidad/).waitFor()
  await buyerPage.getByRole('button',{name:'Paquetes',exact:true}).click()
  await buyerPage.getByRole('button',{name:'Revisar',exact:true}).click()
  await buyerPage.getByLabel('Cantidad recibida').fill('2')
  await buyerPage.getByLabel('Estado del artículo').selectOption('entregado')
  buyerPage.once('dialog',dialog=>dialog.accept())
  await buyerPage.getByRole('button',{name:'Guardar cambios'}).click()
  await buyerPage.getByText('Entregado',{exact:true}).waitFor()
  await ordersPage.getByRole('button',{name:'Sincronizar ahora'}).click()
  await ordersPage.getByRole('button',{name:'Cobros',exact:true}).click()
  await ordersPage.getByText(/\$8\.50 por unidad/).waitFor()
  await ordersPage.getByRole('button',{name:'Copiar todos los precios'}).click()
  assert.match(await ordersPage.getByLabel('Texto preparado').inputValue(),/Subtotal: \$17\.00/)
  await ordersPage.getByRole('button',{name:'Cerrar',exact:true}).click()
  await ordersPage.evaluate(()=>{
    const form=document.createElement('form')
    form.method='POST';form.action='/importar'
    const field=document.createElement('input')
    field.name='share_text';field.value='José\nhttps://www.temu.com/b\nCantidad: 1'
    form.append(field);document.body.append(form);form.submit()
  })
  await ordersPage.getByRole('heading',{name:'Importar desde WhatsApp'}).waitFor()
  assert.match(await ordersPage.getByLabel('Mensaje original').inputValue(),/José/)
  assert.equal(new URL(ordersPage.url()).hash,'')
  assert.deepEqual(errors,[])
  console.log('Navegador móvil y escritorio: pedido offline, sincronización, compra, precio, entrega y mensaje de WhatsApp.')
} finally {
  await browser?.close()
  server.kill()
  await new Promise(resolve=>api.close(resolve))
  await db.close()
}
