import assert from 'node:assert/strict'
import {mkdtemp,readFile,rm,writeFile} from 'node:fs/promises'
import {execFileSync} from 'node:child_process'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {after,before,test} from 'node:test'
import {PGlite} from '@electric-sql/pglite'

const db=new PGlite()
const buyers='10000000-0000-4000-8000-000000000001'
const orders='10000000-0000-4000-8000-000000000002'
const outsider='10000000-0000-4000-8000-000000000003'
const migration=await readFile(new URL('../supabase/migrations/202611130001_orders.sql',import.meta.url),'utf8')
const client=crypto.randomUUID(), item=crypto.randomUUID()
const clientData={name:'María',phone:'',notes:''}
const itemData={client,name:'Camiseta',url:'https://share.temu.com/xyz',qty:2,status:'pendiente',category:'ropa',variants:[{label:'Talla',value:'M'}],required:['Talla','Color'],files:[],notes:''}
const op=(id,kind,data,base=0,archived=false)=>({id,kind,data,base,archived,op:crypto.randomUUID()})
async function act(uid,fn) {
  return db.transaction(async tx=>{
    await tx.exec('set local role authenticated')
    await tx.query("select set_config('request.jwt.claim.sub',$1,true)",[uid])
    return fn(tx)
  })
}
function apply(uid,ops) {return act(uid,tx=>tx.query('select public.apply_operations($1::jsonb)',[JSON.stringify(ops)]))}
before(async()=>{
  await db.exec(`create role anon;create role authenticated;
    create schema auth;create schema storage;create table auth.users(id uuid primary key);
    create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
    create table storage.buckets(id text primary key,name text,public boolean,file_size_limit int,allowed_mime_types text[]);
    create table storage.objects(id uuid default gen_random_uuid(),bucket_id text,name text);
    alter table storage.objects enable row level security;grant usage on schema auth,storage to authenticated;
    grant select,insert on storage.objects to authenticated;`)
  await db.exec(migration)
  await db.query('insert into auth.users values($1),($2),($3)',[buyers,orders,outsider])
  await db.query("insert into public.staff values($1,'compras'),($2,'pedidos')",[buyers,orders])
})
after(()=>db.close())
test('cuentas ajenas no leen, escriben ni adjuntan',async()=>{
  await apply(orders,[op(client,'client',clientData)])
  assert.equal((await act(outsider,tx=>tx.query('select * from public.records'))).rows.length,0)
  await assert.rejects(apply(outsider,[op(item,'item',itemData)]),/Cuenta sin autorización/)
  await assert.rejects(act(outsider,tx=>tx.query("insert into storage.objects(bucket_id,name) values('pedido-fotos',$1)",[item+'/'+item+'.jpg'])),/row-level security/)
})
test('pedidos crea artículos y solo compras publica precios',async()=>{
  await apply(orders,[op(item,'item',itemData)])
  await assert.rejects(apply(orders,[op(item,'item',{...itemData,final:850},1)]),/rol/)
  await assert.rejects(act(orders,tx=>tx.query("update public.records set data='{}'")),/permission denied/)
  await apply(buyers,[op(item,'item',{...itemData,final:850},1)])
  const result=await act(orders,tx=>tx.query('select data from public.records where id=$1',[item]))
  assert.equal(result.rows[0].data.final,850)
})
test('reintento idempotente, versiones obsoletas y variantes requeridas',async()=>{
  await assert.rejects(apply(buyers,[op(item,'item',{...itemData,status:'comprado'},2)]),/Falta la variante/)
  const edit=op(item,'item',{...itemData,final:850,variants:[...itemData.variants,{label:'Color',value:'Negro'}],status:'comprado'},2)
  await apply(buyers,[edit])
  await apply(buyers,[edit])
  await assert.rejects(apply(buyers,[op(item,'item',itemData,2)]),/CONFLICT/)
  await assert.rejects(apply(orders,[op(item,'item',{...edit.data,qty:3},3)]),/rol/)
  const audit=await act(buyers,tx=>tx.query('select * from public.activity where operation=$1',[edit.op]))
  assert.equal(audit.rows.length,1)
  assert.equal(audit.rows[0].actor,buyers)
})
test('transacción parcial revierte todos los cambios y valida recepción',async()=>{
  const another=crypto.randomUUID()
  await assert.rejects(apply(buyers,[op(another,'client',{...clientData,name:'Mon'}),op(item,'item',{...itemData,status:'entregado',required:['Talla'],received:1},3)]),/cantidad completa/)
  assert.equal((await db.query('select * from public.records where id=$1',[another])).rows.length,0)
  await assert.rejects(apply(buyers,[op(client,'client',clientData,1,true)]),/asociados/)
})
test('respaldo solo para compras',async()=>{
  await assert.rejects(act(orders,tx=>tx.query('select public.export_backup()')),/exclusiva/)
  const {rows}=await act(buyers,tx=>tx.query('select public.export_backup() as backup'))
  assert.equal(rows[0].backup.records.length,2)
  assert.equal(rows[0].backup.activity.length,4)
})

test('restaurar conserva versiones, historial e identidad',async()=>{
  const dir=await mkdtemp(join(tmpdir(),'pedido-restore-'))
  try{
    const json=join(dir,'respaldo.json'), sql=join(dir,'restaurar.sql')
    const {rows}=await act(buyers,tx=>tx.query('select public.export_backup() as backup'))
    const expected=rows[0].backup
    await writeFile(json,JSON.stringify(expected))
    execFileSync('python3',['scripts/restore.py',json,sql])
    const script=await readFile(sql,'utf8')
    await assert.rejects(db.exec(script),/requiere una base/)
    await db.exec('rollback')
    await db.exec('truncate public.activity,public.records')
    await db.exec(script)
    const recovered=(await act(buyers,tx=>tx.query('select public.export_backup() as backup'))).rows[0].backup
    assert.deepEqual(recovered.records,expected.records)
    assert.deepEqual(recovered.activity,expected.activity)
  }finally{await rm(dir,{force:true,recursive:true})}
})
