import assert from 'node:assert/strict'
import {test} from 'node:test'
import {blankItem,defaultSettings,operation,project,parseMessage,suggestPrice,toCents,temuUrl,priceList,totals,csv} from '../src/domain.ts'

test('centavos exactos, reglas y prioridad de comisión',()=>{
  assert.equal(toCents('8,50'),850)
  assert.throws(()=>toCents('8.509'))
  assert.equal(suggestPrice({original:701,cost:700,extra:10,discount:50},{...blankItem,category:'ropa'},{...defaultSettings,rounding:50}),850)
  assert.equal(suggestPrice({original:700,commission:0},blankItem,defaultSettings,{commission:20}),700)
  assert.equal(suggestPrice({},blankItem,defaultSettings),undefined)
})
test('WhatsApp detecta bloques y conserva cantidad desconocida',()=>{
  const candidates=parseMessage('María\nhttps://temu.com/a\nTalla M\nColor negro\n\nJosé\nhttps://www.temu.com/b\nTalla 42\nMaterial: Tela\nCantidad: 2')
  assert.equal(candidates.length,2)
  assert.equal(candidates[0].qty,'')
  assert.equal(candidates[0].variants[1].value,'negro')
  assert.equal(candidates[1].clientName,'José')
  assert.equal(candidates[1].variants[1].label,'Material')
  assert.equal(candidates[1].qty,'2')
})
test('solo enlaces originales de dominios Temu',()=>{
  for(const url of ['https://temu.com.evil.invalid/x','https://temu.com@other.invalid','javascript:alert(1)','http://temu.com/x','https://temu.com\\@evil.invalid']) assert.equal(temuUrl(url),false,url)
  assert.equal(temuUrl('https://share.temu.com/abc'),true)
})
test('proyección conserva cambios encadenados y respeta una versión más nueva',()=>{
  const one=operation('item',blankItem)
  const rows=project([],[{ops:[one],uploads:[]}])
  const two=operation('item',{...blankItem,qty:5},rows[0])
  assert.equal(project([],[{ops:[one,two],uploads:[]}])[0].version,2)
  assert.equal(project([{...rows[0],version:3}],[{ops:[one,two],uploads:[]}])[0].data.qty,1)
})
test('mensajes distinguen unitario, subtotal y saldo; la caja incluye reembolsos',()=>{
  const client={id:'c',data:{name:'María'}}
  const product={id:'a',data:{...blankItem,client:'c',qty:2,name:'Camiseta',final:850,cost:600,status:'comprado'}}
  const payment={data:{client:'c',amount:900}}
  const refund={data:{item:'a',type:'temu',amount:100}}
  assert.match(priceList([product],[client],[payment],[refund]),/Precio unitario: \$8\.50\nSubtotal: \$17\.00/)
  assert.match(priceList([product],[client],[payment],[refund]),/Saldo: \$8\.00/)
  assert.equal(totals([product],[payment],[refund]).real,-200)
  assert.match(csv([['=2+2']]),/'=2\+2/)
})
