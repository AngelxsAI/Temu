begin;
create table public.staff (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('compras','pedidos'))
);
create table public.records (
  id uuid primary key,
  kind text not null check (kind in ('client','item','lot','payment','refund','settings','incident','template')),
  data jsonb not null check (jsonb_typeof(data) = 'object'),
  version integer not null default 1 check (version > 0),
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index records_kind_idx on public.records(kind,id);
create index records_client_idx on public.records ((data->>'client'));
create index records_lot_idx on public.records ((data->>'lot'));
create index records_item_idx on public.records ((data->>'item'));
create table public.activity (
  id bigint generated always as identity primary key,
  record_id uuid not null,
  kind text not null,
  actor uuid not null,
  operation uuid not null unique,
  before_value jsonb,
  after_value jsonb not null,
  at timestamptz not null default now()
);
create index activity_record_idx on public.activity(record_id,id desc);
alter table public.staff enable row level security;
alter table public.records enable row level security;
alter table public.activity enable row level security;
revoke all on public.staff,public.records,public.activity from public,anon,authenticated;
grant select on public.staff,public.records,public.activity to authenticated;
create policy own_staff on public.staff for select to authenticated using (user_id=auth.uid());
create function public.staff_role() returns text language sql stable security definer
set search_path = '' as $$ select role from public.staff where user_id=auth.uid() $$;
revoke all on function public.staff_role() from public,anon,authenticated;
grant execute on function public.staff_role() to authenticated;
create policy read_records on public.records for select to authenticated using (public.staff_role() is not null);
create policy read_activity on public.activity for select to authenticated using (public.staff_role() is not null);

create function public.check_fields(p jsonb, limits jsonb) returns void
language plpgsql set search_path = '' as $$
declare f text; lim integer;
begin
  for f,lim in select key,value::text::integer from jsonb_each(limits) loop
    if p ? f and (jsonb_typeof(p->f) <> 'string' or length(p->>f) > lim)
    then raise exception 'Campo de texto no válido: %', f; end if;
  end loop;
end $$;
create function public.check_integer(p jsonb, f text, lo integer, hi integer) returns integer
language plpgsql set search_path = '' as $$
declare n numeric;
begin
  if jsonb_typeof(p->f) is distinct from 'number' then raise exception 'Número requerido: %',f; end if;
  n := (p->>f)::numeric;
  if n <> trunc(n) or n not between lo and hi then raise exception 'Número fuera de rango: %',f; end if;
  return n::integer;
end $$;
create function public.require_record(r text, k text, allow_archived boolean default false) returns void
language plpgsql set search_path = '' as $$
begin
  if not exists (select 1 from public.records where id=r::uuid and kind=k and (allow_archived or not archived))
  then raise exception 'Registro relacionado no disponible: %',k; end if;
end $$;
create function public.validate_record(k text, p jsonb, rid uuid, previous jsonb) returns void
language plpgsql set search_path = '' as $$
declare fields text[]; f text; a jsonb; v record; q integer; received integer; x text;
begin
  if jsonb_typeof(p) is distinct from 'object' or octet_length(p::text)>32768
  then raise exception 'Datos inválidos o demasiado grandes'; end if;
  fields := case k
    when 'client' then array['name','phone','notes','commission']
    when 'item' then array['client','url','name','qty','category','variants','required','notes','lot','status','received','original','cost','commission','extra','discount','final','manual','files']
    when 'lot' then array['name','date','tracking','status','notes']
    when 'payment' then array['client','amount','type','date','notes']
    when 'refund' then array['item','amount','type','date','notes']
    when 'incident' then array['item','status','received','notes','files','date']
    when 'template' then array['name','url','qty','category','variants','required','notes']
    when 'settings' then array['clothing','other','rounding']
    else array[]::text[] end;
  if exists (select 1 from jsonb_object_keys(p) t(key) where not key=any(fields))
  then raise exception 'Campo desconocido'; end if;
  perform public.check_fields(p,'{"name":160,"phone":40,"notes":3000,"tracking":140,"url":3000,"date":10,"category":20,"status":30,"type":30}');
  if k in ('client','lot','template') and coalesce(btrim(p->>'name'),'')='' then raise exception 'Escribe un nombre'; end if;
  if k in ('lot','payment','refund','incident') and (coalesce(p->>'date','') !~ '^\d{4}-\d{2}-\d{2}$' or (p->>'date')::date is null)
  then raise exception 'Fecha inválida'; end if;
  if k='client' and p ? 'commission' then perform public.check_integer(p,'commission',0,1000000); end if;
  if k='lot' and coalesce(p->>'status','') not in ('abierto','en_transito','recibido','cerrado') then raise exception 'Estado de lote inválido'; end if;
  if k in ('payment','refund') then
    perform public.check_integer(p,'amount',1,100000000);
    if k='payment' then
      if coalesce(p->>'type','') not in ('pago','anticipo') then raise exception 'Tipo de pago inválido'; end if;
      perform public.require_record(p->>'client','client',p->>'client' is not distinct from previous->>'client');
    else
      if coalesce(p->>'type','') not in ('temu','cliente') then raise exception 'Tipo de reembolso inválido'; end if;
      perform public.require_record(p->>'item','item',p->>'item' is not distinct from previous->>'item');
    end if;
  end if;
  if k='settings' then
    if rid <> '00000000-0000-4000-8000-000000000001'::uuid then raise exception 'Identificador de ajustes inválido'; end if;
    perform public.check_integer(p,'clothing',0,1000000);
    perform public.check_integer(p,'other',0,1000000);
    perform public.check_integer(p,'rounding',1,10000);
  end if;
  if k in ('item','template') then
    q := public.check_integer(p,'qty',1,10000);
    if coalesce(p->>'url','') !~* '^https://([a-z0-9-]+\.)*temu\.com([/?#][^[:space:]\\]*)?$'
    then raise exception 'Introduce un enlace HTTPS de Temu'; end if;
    if coalesce(p->>'category','') not in ('ropa','otros') then raise exception 'Categoría inválida'; end if;
    if jsonb_typeof(p->'variants') is distinct from 'array' or jsonb_typeof(p->'required') is distinct from 'array' then raise exception 'Variantes inválidas'; end if;
    if jsonb_array_length(p->'variants')>40 or jsonb_array_length(p->'required')>40 then raise exception 'Demasiadas variantes'; end if;
    for a in select value from jsonb_array_elements(p->'variants') loop
      if jsonb_typeof(a)<>'object' or a-array['label','value']<>'{}'::jsonb or coalesce(btrim(a->>'label'),'')='' or coalesce(btrim(a->>'value'),'')=''
      then raise exception 'Completa el nombre y valor de cada variante'; end if;
      perform public.check_fields(a,'{"label":80,"value":300}');
    end loop;
    if exists (select 1 from jsonb_array_elements(p->'variants') e group by lower(btrim(e->>'label')) having count(*)>1)
    then raise exception 'Hay nombres de variantes repetidos'; end if;
    for a in select value from jsonb_array_elements(p->'required') loop
      x := a#>>'{}';
      if jsonb_typeof(a)<>'string' or length(btrim(x)) not between 1 and 80 then raise exception 'Variante requerida inválida'; end if;
      if k='item' and p->>'status' not in ('pendiente','agotado','problema') and not exists
        (select 1 from jsonb_array_elements(p->'variants') e where lower(btrim(e->>'label'))=lower(btrim(x)))
      then raise exception 'Falta la variante %',x; end if;
    end loop;
  end if;
  if k='item' then
    perform public.require_record(p->>'client','client',p->>'client' is not distinct from previous->>'client');
    if p ? 'lot' then perform public.require_record(p->>'lot','lot',p->>'lot' is not distinct from previous->>'lot'); end if;
    foreach f in array array['original','cost','commission','extra','discount','final'] loop
      if p ? f then perform public.check_integer(p,f,0,100000000); end if;
    end loop;
    if p ? 'manual' and jsonb_typeof(p->'manual') <> 'boolean' then raise exception 'Modo de precio inválido'; end if;
  end if;
  if k='incident' then
    perform public.require_record(p->>'item','item',p->>'item' is not distinct from previous->>'item');
    select (data->>'qty')::integer into q from public.records where id=(p->>'item')::uuid;
    if coalesce(btrim(p->>'notes'),'')='' then raise exception 'Describe la incidencia'; end if;
  end if;
  if k in ('item','incident') then
    if coalesce(p->>'status','') not in ('pendiente','comprado','agotado','problema','en_transito','recibido','correcto','variante_incorrecta','defectuoso','incompleto','no_recibido','en_devolucion','reembolsado','entregado')
    then raise exception 'Estado de artículo inválido'; end if;
    if p ? 'received' then received:=public.check_integer(p,'received',0,q); end if;
    if p->>'status' in ('correcto','entregado') and received is distinct from q then raise exception 'Confirma la cantidad completa antes de marcar correcto o entregado'; end if;
    if p->>'status'='incompleto' and (received is null or received>=q) then raise exception 'Indica una cantidad menor que la esperada'; end if;
    if p->>'status'='no_recibido' and received is distinct from 0 then raise exception 'La cantidad recibida debe ser cero'; end if;
    if jsonb_typeof(p->'files') is distinct from 'array' or jsonb_array_length(p->'files')>12 then raise exception 'Adjuntos inválidos'; end if;
    for a in select value from jsonb_array_elements(p->'files') loop
      if jsonb_typeof(a) <> 'string' or (a#>>'{}') !~ ('^'||case when k='item' then rid::text else p->>'item' end||'/[0-9a-f-]{36}\.(jpg|png|webp)$')
      then raise exception 'Ruta de adjunto inválida'; end if;
    end loop;
  end if;
end $$;

create function public.apply_operations(ops jsonb) returns void language plpgsql security definer
set search_path = '' as $$
declare role text:=public.staff_role(); op jsonb; rid uuid; oid uuid; k text; p jsonb;
  wanted integer; tomb boolean; prior public.records; nextrow public.records; existing public.activity;
  protected text[]:=array['lot','received','original','cost','commission','extra','discount','final','manual'];
begin
  if role is null then raise exception 'Cuenta sin autorización' using errcode='42501'; end if;
  if jsonb_typeof(ops) is distinct from 'array' or jsonb_array_length(ops) not between 1 and 200
  then raise exception 'Lote de cambios inválido'; end if;
  perform pg_advisory_xact_lock(21792,1);
  for op in select value from jsonb_array_elements(ops) loop
    rid:=(op->>'id')::uuid; oid:=(op->>'op')::uuid; k:=op->>'kind'; p:=op->'data';
    wanted:=(op->>'base')::integer; tomb:=(op->>'archived')::boolean;
    if rid is null or oid is null or k is null or wanted is null or wanted<0 or tomb is null then raise exception 'Operación inválida'; end if;
    select * into existing from public.activity where operation=oid;
    if found then
      if existing.actor<>auth.uid() or existing.record_id<>rid or existing.kind<>k or
         existing.after_value->'data' is distinct from p or
         (existing.after_value->>'archived')::boolean is distinct from tomb or
         (existing.after_value->>'version')::integer <> wanted+1
      then raise exception 'Identificador de operación reutilizado'; end if;
      continue;
    end if;
    select * into prior from public.records where id=rid;
    if coalesce(prior.version,0)<>wanted or (prior.id is not null and prior.kind<>k) then
      raise exception 'CONFLICT:%',rid using errcode='40001';
    end if;
    if role='pedidos' and (k not in ('client','item','template') or tomb is distinct from coalesce(prior.archived,false)
      or (k='client' and p->'commission' is distinct from prior.data->'commission')
      or (k='item' and (
        p->>'status' is distinct from coalesce(prior.data->>'status','pendiente')
        or exists(select 1 from unnest(protected) t(f) where p->f is distinct from prior.data->f)
        or (prior.data->>'status' not in ('pendiente','agotado','problema') and (p-array['notes','files','name']) is distinct from (prior.data-array['notes','files','name']))
      ))) then raise exception 'Tu rol no puede cambiar estos datos' using errcode='42501'; end if;
    perform public.validate_record(k,p,rid,prior.data);
    if tomb and k in ('client','lot') and exists (select 1 from public.records where not archived and
      ((k='client' and data->>'client'=rid::text) or (k='lot' and data->>'lot'=rid::text))) then
      raise exception 'El registro aún tiene artículos o movimientos asociados';
    end if;
    if not tomb and coalesce(prior.archived,false) then
      if p ? 'client' then perform public.require_record(p->>'client','client'); end if;
      if p ? 'lot' then perform public.require_record(p->>'lot','lot'); end if;
      if p ? 'item' then perform public.require_record(p->>'item','item'); end if;
    end if;
    insert into public.records(id,kind,data,archived) values(rid,k,p,tomb)
    on conflict(id) do update set data=excluded.data,archived=excluded.archived,
      version=public.records.version+1,updated_at=now() returning * into nextrow;
    insert into public.activity(record_id,kind,actor,operation,before_value,after_value)
    values(rid,k,auth.uid(),oid,case when prior.id is not null then to_jsonb(prior) end,to_jsonb(nextrow));
  end loop;
end $$;
revoke all on function public.apply_operations(jsonb) from public,anon,authenticated;
grant execute on function public.apply_operations(jsonb) to authenticated;
revoke all on function public.check_fields(jsonb,jsonb),public.check_integer(jsonb,text,integer,integer),
  public.require_record(text,text,boolean),public.validate_record(text,jsonb,uuid,jsonb) from public,anon,authenticated;

create function public.export_backup() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
  if public.staff_role() is distinct from 'compras' then raise exception 'Operación exclusiva de compras' using errcode='42501'; end if;
  return jsonb_build_object('format',1,'created_at',now(),'records',
    coalesce((select jsonb_agg(to_jsonb(r) order by r.id) from public.records r),'[]'::jsonb),
    'activity',coalesce((select jsonb_agg(to_jsonb(a) order by a.id) from public.activity a),'[]'::jsonb));
end $$;
revoke all on function public.export_backup() from public,anon,authenticated;
grant execute on function public.export_backup() to authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('pedido-fotos','pedido-fotos',false,2097152,array['image/jpeg','image/png','image/webp']);
create policy order_files_read on storage.objects for select to authenticated
using (bucket_id='pedido-fotos' and public.staff_role() is not null);
create policy order_files_insert on storage.objects for insert to authenticated
with check (bucket_id='pedido-fotos' and public.staff_role() is not null
  and name ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}\.(jpg|png|webp)$');
commit;
