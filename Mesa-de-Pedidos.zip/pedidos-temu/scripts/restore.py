"""Generate a transaction for restoring a backup in an empty, migrated project."""
import argparse
import base64
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("backup", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
backup = json.loads(args.backup.read_text(encoding="utf-8"))
if (
    not isinstance(backup, dict)
    or backup.get("format") != 1
    or not all(isinstance(backup.get(key), list) for key in ("records", "activity"))
    or not all(isinstance(row, dict) for key in ("records", "activity") for row in backup[key])
):
    parser.error("El archivo no tiene el formato de respaldo 1.")

encoded = base64.b64encode(json.dumps(backup, ensure_ascii=False).encode()).decode()
sql = f"""begin;
select pg_advisory_xact_lock(21792,1);
lock table public.records, public.activity in access exclusive mode;
create temporary table restore_payload on commit drop as
select convert_from(decode('{encoded}', 'base64'), 'UTF8')::jsonb as body;
do $$
begin
  if exists(select 1 from public.records) or exists(select 1 from public.activity)
  then raise exception 'La restauración requiere una base de pedidos vacía'; end if;
end $$;
insert into public.records select r.*
from restore_payload p cross join lateral jsonb_populate_recordset(null::public.records,p.body->'records') r;
insert into public.activity overriding system value select a.*
from restore_payload p cross join lateral jsonb_populate_recordset(null::public.activity,p.body->'activity') a;
do $$
begin
  if exists (
    select 1 from public.records r
    cross join lateral (values (r.data->>'client','client'),(r.data->>'item','item'),(r.data->>'lot','lot')) ref(id,kind)
    where ref.id is not null and not exists
      (select 1 from public.records target where target.id=ref.id::uuid and target.kind=ref.kind)
  ) then raise exception 'El respaldo contiene referencias sin destino'; end if;
  if exists(select 1 from public.activity a where not exists (select 1 from public.records r where r.id=a.record_id))
  then raise exception 'La auditoría contiene registros sin destino'; end if;
end $$;
select setval(pg_get_serial_sequence('public.activity','id'),coalesce((select max(id) from public.activity),1),exists(select 1 from public.activity));
select kind,count(*) from public.records group by kind order by kind;
commit;
"""
with args.output.open("x", encoding="utf-8") as output:
    args.output.chmod(0o600)
    output.write(sql)
print(f"Respaldo preparado. Registros: {len(backup['records'])}. Cambios: {len(backup['activity'])}.")
