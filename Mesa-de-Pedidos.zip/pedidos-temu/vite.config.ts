import { defineConfig } from 'vite'
import tailwindcss from '@tailwindcss/vite'
import { createHash } from 'node:crypto'

export default defineConfig({
  plugins: [tailwindcss(), {
    name: 'offline-shell',
    apply: 'build',
    enforce: 'post',
    generateBundle(_, bundle) {
      const assets = Object.keys(bundle)
      const cache = 'pedidos-' + createHash('sha256').update(assets.join('|') + JSON.stringify(bundle['index.html']) + 'sw-post-share-v1').digest('hex').slice(0, 12)
      this.emitFile({type: 'asset', fileName: 'sw.js', source: `
const CACHE = '${cache}';
const SHELL = ${JSON.stringify(['/', '/manifest.webmanifest', '/icon-192.png', '/icon-512.png', ...assets.map(path => '/' + path)])};
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL))));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('pedidos-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())));
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname === '/importar' && event.request.method === 'POST') {
    event.respondWith((async () => {
      const form = await event.request.formData();
      const input = ['share_text', 'share_url'].map(name => form.get(name)).filter(value => typeof value === 'string' && value);
      return Response.redirect(new URL('/#import=' + encodeURIComponent([...new Set(input)].join('\\n').slice(0,24000)), self.location.origin), 303);
    })());
    return;
  }
  if (event.request.method !== 'GET') return;
  if (event.request.mode === 'navigate') event.respondWith(fetch(event.request).catch(() => caches.match('/')));
  else if (SHELL.includes(url.pathname)) event.respondWith(caches.match(url.pathname).then(response => response || fetch(event.request)));
});
`})
    },
  }],
})
