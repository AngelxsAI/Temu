export const labels = {
  pendiente:'Pendiente', comprado:'Comprado', agotado:'Agotado', problema:'Problema',
  en_transito:'En tránsito', recibido:'Recibido', correcto:'Correcto', variante_incorrecta:'Variante incorrecta',
  defectuoso:'Defectuoso', incompleto:'Incompleto', no_recibido:'No recibido', en_devolucion:'En devolución',
  reembolsado:'Reembolsado', entregado:'Entregado',
} as const
export type Status = keyof typeof labels
export const issues: Status[] = ['problema','variante_incorrecta','defectuoso','incompleto','no_recibido','en_devolucion']
export const purchased: Status[] = ['comprado','en_transito','recibido','correcto','variante_incorrecta','defectuoso','incompleto','no_recibido','en_devolucion','reembolsado','entregado']
export const reviewed: Status[] = ['recibido','correcto','variante_incorrecta','defectuoso','incompleto','no_recibido','en_devolucion','reembolsado','entregado']
export const lotLabels = {abierto:'Abierto',en_transito:'En tránsito',recibido:'Recibido',cerrado:'Cerrado'}
export type Role = 'compras' | 'pedidos'
export type Variant = {label:string;value:string}
export type Client = {name:string;phone:string;notes:string;commission?:number}
export type Product = {name:string;url:string;qty:number;category:'ropa'|'otros';variants:Variant[];required:string[];notes:string}
export type Pricing = {original?:number;cost?:number;commission?:number;extra?:number;discount?:number;final?:number;manual?:boolean}
export type Item = Product & Pricing & {client:string;status:Status;files:string[];lot?:string;received?:number}
export type Lot = {name:string;date:string;tracking:string;status:keyof typeof lotLabels;notes:string}
export type Payment = {client:string;amount:number;type:'pago'|'anticipo';date:string;notes:string}
export type Refund = {item:string;amount:number;type:'temu'|'cliente';date:string;notes:string}
export type Incident = {item:string;status:Status;received?:number;notes:string;date:string;files:string[]}
export type Settings = {clothing:number;other:number;rounding:number}
export type RecordData = {client:Client;item:Item;lot:Lot;payment:Payment;refund:Refund;incident:Incident;settings:Settings;template:Product}
export type Kind = keyof RecordData
export type Row<K extends Kind = Kind> = {id:string;kind:K;data:RecordData[K];archived:boolean;version:number;created_at:string;updated_at:string}
export type Op = {id:string;kind:Kind;data:RecordData[Kind];archived:boolean;base:number;op:string}
export type Upload = {path:string;file:Blob}
export type Batch = {ops:Op[];uploads:Upload[]}
export const settingsId = '00000000-0000-4000-8000-000000000001'
export const defaultSettings: Settings = {clothing:150,other:100,rounding:1}
export const blankProduct: Product = {name:'',url:'',qty:1,category:'otros',variants:[],required:[],notes:''}
export const blankItem: Item = {...blankProduct,client:'',status:'pendiente',files:[]}

export function byKind<K extends Kind>(rows:Row[],kind:K,archived=false):Row<K>[] {
  return rows.filter(row=>row.kind===kind && row.archived===archived) as Row<K>[]
}
export function nameOf(id:string, clients:Row<'client'>[]) {
  return clients.find(client=>client.id===id)?.data.name ?? 'Cliente archivado'
}
export function fold(value:string) {
  return value.normalize('NFD').replace(/\p{Diacritic}/gu,'').toLowerCase().trim()
}
export function temuUrl(value:string) {
  if (!/^https:\/\/([a-z0-9-]+\.)*temu\.com([/?#][^\s\\]*)?$/i.test(value)) return false
  try { return new URL(value).protocol === 'https:' } catch { return false }
}
export function missingVariants(product:Product) {
  return product.required.filter(label=>!product.variants.some(variant=>fold(variant.label)===fold(label)&&variant.value.trim()))
}
export function money(value:number) {
  return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(value/100)
}
export function toCents(input:string):number|undefined {
  const value=input.trim().replace(',','.')
  if (!value) return undefined
  if (!/^\d{1,7}(\.\d{1,2})?$/.test(value)) throw new Error('Escribe un importe positivo con hasta dos decimales.')
  const [integer,fraction='']=value.split('.')
  const cents=Number(integer)*100+Number(fraction.padEnd(2,'0'))
  if(cents>100000000) throw new Error('El importe es demasiado alto.')
  return cents
}
export function moneyInput(value:number|undefined) { return value===undefined ? '' : (value/100).toFixed(2) }
const businessDate=new Intl.DateTimeFormat('sv-SE',{timeZone:'America/El_Salvador'})
export function localDate(iso:string) { return businessDate.format(new Date(iso)) }
export function today() { return businessDate.format(new Date()) }
export function suggestPrice(p:Pricing, item:Item, settings:Settings, client?:Client) {
  const base=p.cost ?? p.original
  if(base===undefined) return undefined
  const fee=p.commission ?? client?.commission ?? (item.category==='ropa'?settings.clothing:settings.other)
  const total=Math.max(0,base+fee+(p.extra??0)-(p.discount??0))
  return Math.ceil(total/settings.rounding)*settings.rounding
}
export function operation<K extends Kind>(kind:K,data:RecordData[K],row?:Row<K>,archived=row?.archived??false,id=row?.id??crypto.randomUUID()):Op {
  return {kind,data,archived,id,base:row?.version??0,op:crypto.randomUUID()}
}
export function project(rows:Row[],queue:Batch[]) {
  const map=new Map(rows.map(row=>[row.id,row]))
  for(const batch of queue) for(const op of batch.ops) {
    const old=map.get(op.id)
    if(old && old.version>op.base) continue
    const now=new Date().toISOString()
    map.set(op.id,{id:op.id,kind:op.kind,data:op.data,archived:op.archived,version:op.base+1,created_at:old?.created_at??now,updated_at:now})
  }
  return [...map.values()]
}
export function filterByCustomer(items:Row<'item'>[],client:string) { return items.filter(item=>item.data.client===client) }
export function totals(items:Row<'item'>[],payments:Row<'payment'>[],refunds:Row<'refund'>[]) {
  const activeItems=items.filter(r=>r.data.status!=='agotado')
  const activeIds=new Set(activeItems.map(r=>r.id))
  const sales=activeItems.reduce((sum,r)=>sum+(r.data.final??0)*r.data.qty,0)
  const temu=refunds.filter(r=>activeIds.has(r.data.item)&&r.data.type==='temu').reduce((sum,r)=>sum+r.data.amount,0)
  const returned=refunds.filter(r=>activeIds.has(r.data.item)&&r.data.type==='cliente').reduce((sum,r)=>sum+r.data.amount,0)
  const paid=payments.reduce((sum,r)=>sum+r.data.amount,0)
  const estimated=activeItems.reduce((sum,{data:p})=>p.final===undefined || (p.cost??p.original)===undefined ? sum : sum+(p.final-(p.cost??p.original??0)-(p.extra??0))*p.qty,0)
  const realCosts=activeItems.reduce((sum,{data:p})=>purchased.includes(p.status)&&p.cost!==undefined ? sum+(p.cost+(p.extra??0))*p.qty : sum,0)
  const missingCosts=activeItems.filter(({data:p})=>purchased.includes(p.status)&&p.cost===undefined).length
  return {sales,netSales:sales-returned,paid,due:sales-returned-paid,estimated:estimated+temu-returned,real:paid-returned-realCosts+temu,missingCosts,realCosts}
}
export function specs(p:Product) {
  return [...p.variants.map(v=>v.label+': '+v.value),'Cantidad: '+p.qty,...(p.notes?['Notas: '+p.notes]:[])].join('\n')
}
export function purchaseList(items:Row<'item'>[],clients:Row<'client'>[]) {
  return items.map(({data:p},index)=>`${index+1}. ${nameOf(p.client,clients)} — ${p.name||'Producto de Temu'}\n${specs(p)}\nURL: ${p.url}`).join('\n\n')
}
export function priceList(items:Row<'item'>[],clients:Row<'client'>[],payments:Row<'payment'>[],refunds:Row<'refund'>[],pending=false,summary=false) {
  return clients.flatMap(client=>{
    const products=filterByCustomer(items,client.id).filter(r=>r.data.status!=='agotado')
    if(!products.length) return []
    const total=totals(products,payments.filter(r=>r.data.client===client.id),refunds)
    if(pending&&total.due<=0) return []
    const unknown=products.filter(r=>r.data.final===undefined).length
    if(summary) return [`${client.data.name} · Total ${money(total.netSales)} · Saldo ${money(total.due)}${unknown?' · Precios pendientes: '+unknown:''}`]
    const lines=products.map(({data:p},index)=>{
      const price=p.final===undefined?'Precio pendiente':`Precio unitario: ${money(p.final)}\nSubtotal: ${money(p.final*p.qty)}`
      return `${index+1}. ${p.name||'Producto de Temu'}\n${p.variants.map(v=>v.label+': '+v.value+'\n').join('')}Cantidad: ${p.qty}\n${price}`
    })
    return [`PEDIDO DE ${client.data.name.toLocaleUpperCase('es')}\n\n${lines.join('\n\n')}\n\n${unknown?'TOTAL DE ARTÍCULOS COTIZADOS':'TOTAL'}: ${money(total.netSales)}${total.paid?'\nPagado: '+money(total.paid):''}${total.due!==total.netSales?'\nSaldo: '+money(total.due):''}`]
  }).join('\n\n')
}
export function csv(rows:(string|number)[][]) {
  return '\uFEFF'+rows.map(row=>row.map(cell=>{
    const text=String(cell)
    const safe=typeof cell==='string'&&/^[\s\uFEFF]*[=+\-@\t\r]/.test(text)?"'"+text:text
    return '"'+safe.replaceAll('"','""')+'"'
  }).join(',')).join('\r\n')
}

export type Candidate = {key:string;clientName:string;url:string;variants:Variant[];qty:string;warnings:string[];source:string}
const knownVariant=/^(talla|color|diseño|modelo|material|capacidad|medidas?|número|versión|personalización)\s*(?::\s*|\s+)(.+)$/i
export function parseMessage(input:string):Candidate[] {
  const candidates:Candidate[]=[]
  let nextName=''
  let raw:string[]=[]
  let variants:Variant[]=[]
  let qty=''
  let current:Candidate|undefined
  let afterBlank=false
  for(const part of input.split(/\r?\n/)) {
    const line=part.trim()
    if(!line){afterBlank=true;continue}
    const urls=line.match(/https?:\/\/[^\s<>]+/gi)??[]
    const variant=line.match(knownVariant)??line.match(/^([^:\d]{1,35}):\s*(.+)$/)
    const number=line.match(/^cantidad\s*:?\s*(\d+)$/i)
    const customer=line.match(/^cliente\s*:\s*(.+)$/i)
    if(urls.length) {
      for(const url of urls) {
        current={key:crypto.randomUUID(),clientName:nextName,url,variants:[...variants],qty,warnings:[],source:[...raw,line].join('\n')}
        if(!temuUrl(url)) current.warnings.push('Revisa el enlace')
        if(line!==url||urls.length>1) current.warnings.push('Revisa el texto junto al enlace')
        candidates.push(current)
      }
      variants=[];raw=[];qty=''
    } else if(customer || (!variant&&!number&&(afterBlank||!current)&& /^[\p{L}][\p{L}\p{M} .'-]{0,48}$/u.test(line))) {
      if(!current&&nextName) raw.push('Cliente anterior: '+nextName)
      nextName=customer?.[1]??line
      current=undefined
    } else if(variant||number) {
      const entry=variant?{label:variant[1].trim(),value:variant[2].trim()}:undefined
      if(current){
        current.source+='\n'+line
        if(entry) current.variants.push(entry)
        if(number) current.qty=number[1]
      } else {
        if(entry) variants.push(entry)
        if(number) qty=number[1]
        raw.push(line)
      }
    } else {
      if(current) {current.source+='\n'+line;current.warnings.push('Texto sin clasificar')}
      else raw.push(line)
    }
    afterBlank=false
  }
  if(raw.length||(!current&&nextName)) candidates.push({key:crypto.randomUUID(),clientName:nextName,url:'',variants,qty,warnings:['Falta confirmar el enlace'],source:[nextName,...raw].join('\n')})
  return candidates.map(candidate=>({...candidate,warnings:[...new Set([...candidate.warnings,...(!candidate.clientName?['Cliente sin confirmar']:[]),...(!candidate.qty?['Cantidad sin confirmar']:[])])]}))
}
