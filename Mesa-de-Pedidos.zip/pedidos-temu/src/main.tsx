import {useEffect,useState} from 'react'
import {createRoot} from 'react-dom/client'
import type {Session} from '@supabase/supabase-js'
import {Archive, ChevronRight, ClipboardList, Cloud, CloudOff, LayoutDashboard, LogOut, Moon, Settings, ShoppingBag, Sun, Truck, Users, Wallet} from 'lucide-react'
import {api,clearCache,errorText,useOrders} from './sync.ts'
import {blankItem} from './domain.ts'
import type {Item,Row} from './domain.ts'
import {Button,ErrorNote,Field,Modal} from './ui.tsx'
import {ClientEditor,ItemEditor,LotEditor,MovementEditor,PriceEditor,ReviewEditor,SettingsEditor} from './editors.tsx'
import {Articles,Billing,Buying,Customers,Dashboard,HistoryDialog,ImportDialog,MergeDialog,MessagesDialog,Packages,Preferences} from './views.tsx'
import type {Editor,Screen} from './views.tsx'
import './style.css'

const nav=[['Inicio',LayoutDashboard],['Artículos',ClipboardList],['Clientes',Users],['Preparar compra',ShoppingBag],['Paquetes',Truck],['Cobros',Wallet],['Ajustes',Settings]] as const
const incoming=new URLSearchParams(location.hash.slice(1)).get('import')??''
if(incoming) history.replaceState(null,'',location.pathname)

function Brand(){return <div className="brand"><span className="brand-icon"><ShoppingBag size={22}/></span><span>Mesa de Pedidos<small>Gestión Temu</small></span></div>}

function Access({children}:{children:React.ReactNode}) {
  return <div className="access"><main className="card access-card"><Brand/>{children}</main></div>
}
function Login() {
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [busy,setBusy]=useState(false)
  const [error,setError]=useState('')
  return <Access><h1>Iniciar sesión</h1><p className="muted">Usa la cuenta asignada a tu rol.</p><form onSubmit={async e=>{
    e.preventDefault();setBusy(true);setError('')
    try {
      const {error}=await api!.auth.signInWithPassword({email:email.trim(),password})
      if(error)throw error
    }catch{setError('No se pudo iniciar sesión. Revisa el correo, la contraseña y la conexión.')}finally{setBusy(false)}
  }}>
    <Field label="Correo electrónico"><input required type="email" autoComplete="username" value={email} onChange={e=>setEmail(e.target.value)}/></Field>
    <Field label="Contraseña"><input required type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)}/></Field>
    {error&&<ErrorNote>{error}</ErrorNote>}
    <Button type="submit" variant="primary" disabled={busy}>{busy?'Entrando…':'Entrar'}<ChevronRight size={17}/></Button>
  </form></Access>
}

function Workspace({session}:{session:Session}) {
  const uid=session.user.id
  const store=useOrders(uid)
  const [screen,go]=useState<Screen>('Inicio')
  const [customer,customerSet]=useState('')
  const [editor,setEditor]=useState<{name:Editor;id?:string;snapshot?:Row}|undefined>(incoming?{name:'import'}:undefined)
  const [shared,setShared]=useState(incoming)
  const [toast,setToast]=useState('')
  const [fallback,setFallback]=useState('')
  const [theme,setTheme]=useState(()=>localStorage.getItem('mesa-theme')??(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'))
  useEffect(()=>{document.documentElement.dataset.theme=theme;localStorage.setItem('mesa-theme',theme)},[theme])
  useEffect(()=>{if(toast){const timer=window.setTimeout(()=>setToast(''),3200);return ()=>window.clearTimeout(timer)}},[toast])
  const open=(name:Editor,id?:string)=>setEditor({name,id,snapshot:store.rows.find(r=>r.id===id)})
  const close=()=>{if(editor?.name==='import')setShared('');setEditor(undefined)}
  const copy=async(text:string)=>{
    if(!text){setToast('No hay artículos para copiar.');return}
    try {await navigator.clipboard.writeText(text);setToast('Texto copiado.')}catch{setFallback(text)}
  }
  const logout=async()=>{
    if(store.queue.length){setToast('Sincroniza o resuelve los cambios pendientes antes de salir.');return}
    try{
      await clearCache(uid)
      for(const key of Object.keys(sessionStorage))if(key.startsWith(uid+'-'))sessionStorage.removeItem(key)
      const {error}=await api!.auth.signOut({scope:'local'})
      if(error)throw error
    }catch(e){setToast(errorText(e))}
  }
  if(!store.ready)return <Access><p>Consultando pedidos…</p></Access>
  if(!store.role)return <Access><h1>Acceso al negocio</h1><ErrorNote>{store.error||'Conéctate para verificar tu cuenta.'}</ErrorNote><div className="actions"><Button onClick={()=>void store.refresh()}>Reintentar</Button><Button onClick={()=>void logout()}>Cerrar sesión</Button>{store.queue.length>0&&<Button variant="danger" onClick={()=>{if(confirm('¿Descartar los cambios locales pendientes?'))void store.discard()}}>Descartar cola local</Button>}</div>{toast&&<p role="status">{toast}</p>}</Access>
  const item=editor?.snapshot?.kind==='item'?editor.snapshot as Row<'item'>:undefined
  const client=editor?.snapshot?.kind==='client'?editor.snapshot as Row<'client'>:undefined
  const row=store.rows.find(r=>r.id===editor?.id)
  const lot=editor?.snapshot?.kind==='lot'?editor.snapshot as Row<'lot'>:undefined
  const duplicate:Item|undefined=item?{...blankItem,name:item.data.name,url:item.data.url,qty:item.data.qty,category:item.data.category,variants:item.data.variants,required:item.data.required,notes:item.data.notes}:undefined
  const title={compras:'Compras',pedidos:'Pedidos'}[store.role]
  return <div className="layout">
    <aside className="sidebar no-print"><Brand/><nav aria-label="Secciones">{nav.map(([name,Icon])=><button key={name} className={screen===name?'active':''} aria-current={screen===name?'page':undefined} onClick={()=>{if(name==='Artículos')customerSet('');go(name)}}><Icon size={20}/><span>{name}</span></button>)}</nav><div className="sidebar-footer"><span className="avatar">{session.user.email?.slice(0,1).toUpperCase()||'P'}</span><div><strong>{title}</strong><small>{session.user.email}</small></div></div></aside>
    <div className="workspace">
      <header className="topbar no-print"><div className="mobile-brand"><Brand/></div><span className="desktop-page">{screen}</span><div className="top-actions">
        <Button variant="plain" className="sync-button" onClick={()=>void store.refresh()} aria-label="Sincronizar ahora" title={store.online?"Sincronizar ahora":"Sin conexión"}>{store.online?<Cloud size={19}/>:<CloudOff size={19}/>}<span>{store.busy?'Sincronizando':!store.online?'Sin conexión':store.queue.length?store.queue.length+' pendientes':store.error?'Revisar sincronización':'Sincronizado'}</span></Button>
        <Button variant="plain" onClick={()=>setTheme(theme==='dark'?'light':'dark')} aria-label="Cambiar tema">{theme==='dark'?<Sun size={20}/>:<Moon size={20}/>}</Button>
        <Button variant="plain" onClick={()=>void logout()} aria-label="Cerrar sesión"><LogOut size={19}/></Button>
      </div></header>
      <main className="content">
        {store.error&&<div className="sync-error no-print"><ErrorNote>{store.error}</ErrorNote>{store.queue.length>0&&<Button onClick={()=>open('history','sync')}>Resolver cambios pendientes</Button>}</div>}
        {screen==='Inicio'&&<Dashboard store={store} open={open} go={go}/>}
        {screen==='Artículos'&&<Articles store={store} open={open} copy={copy} client={customer} clearClient={()=>customerSet('')}/>}
        {screen==='Clientes'&&<Customers store={store} open={open} showItems={id=>{customerSet(id);go('Artículos')}}/>}
        {screen==='Preparar compra'&&<Buying uid={uid} store={store} open={open} copy={copy}/>}
        {screen==='Paquetes'&&<Packages store={store} open={open} copy={copy}/>}
        {screen==='Cobros'&&<Billing store={store} open={open} copy={copy}/>}
        {screen==='Ajustes'&&<Preferences store={store} open={open}/>}
      </main>
    </div>
    {editor?.name==='item'&&<ItemEditor uid={uid} store={store} row={item} clientId={client?.id} onClose={close}/>}
    {editor?.name==='duplicate'&&duplicate&&<ItemEditor uid={uid+'-duplicate-'+item!.id} store={store} initial={duplicate} onClose={close}/>}
    {editor?.name==='client'&&<ClientEditor store={store} row={client} onClose={close}/>}
    {editor?.name==='lot'&&store.role==='compras'&&<LotEditor store={store} row={lot} onClose={close}/>}
    {editor?.name==='price'&&item&&store.role==='compras'&&<PriceEditor store={store} row={item} onClose={close}/>}
    {editor?.name==='review'&&item&&store.role==='compras'&&<ReviewEditor store={store} row={item} onClose={close}/>}
    {editor?.name==='payment'&&client&&store.role==='compras'&&<MovementEditor store={store} kind="payment" target={client.id} onClose={close}/>}
    {editor?.name==='refund'&&item&&store.role==='compras'&&<MovementEditor store={store} kind="refund" target={item.id} onClose={close}/>}
    {editor?.name==='merge'&&client&&store.role==='compras'&&<MergeDialog store={store} source={client} close={close}/>}
    {editor?.name==='settings'&&store.role==='compras'&&<SettingsEditor store={store} row={editor.snapshot as Row<'settings'>|undefined} onClose={close}/>}
    {editor?.name==='import'&&<ImportDialog store={store} close={close} shared={shared}/>}
    {editor?.name==='messages'&&<MessagesDialog store={store} close={close} id={editor.id} copy={copy}/>}
    {editor?.name==='history'&&row&&<HistoryDialog store={store} row={row} close={close}/>}
    {editor?.name==='history'&&editor.id==='sync'&&<Modal title="Cambios pendientes" onClose={close}><div className="stack"><p>Compara tu edición con los datos del servidor. Puedes copiar tus valores antes de descartar la cola y volver a aplicarlos al registro actual.</p>
      {store.queue.flatMap(b=>b.ops).map(op=><details className="card candidate" key={op.op}><summary>{op.kind} · {op.id.slice(0,8)}</summary><pre>{JSON.stringify({local:op.data,servidor:store.remote.find(r=>r.id===op.id)?.data??null},null,2)}</pre></details>)}
      <div className="actions"><Button onClick={()=>void store.refresh()}>Reintentar</Button><Button variant="danger" onClick={async()=>{if(confirm('¿Descartar todos los cambios pendientes de este dispositivo?')){await store.discard();close()}}}><Archive size={17}/>Descartar cola local</Button></div>
    </div></Modal>}
    {fallback&&<Modal title="Copiar manualmente" onClose={()=>setFallback('')}><textarea className="message" readOnly value={fallback} onFocus={e=>e.target.select()}/></Modal>}
    {toast&&<div className="toast" role="status">{toast}</div>}
  </div>
}
function App() {
  const [session,setSession]=useState<Session|null|undefined>()
  useEffect(()=>{
    if(!api)return
    const {data:{subscription}}=api.auth.onAuthStateChange((_event,value)=>setSession(value))
    return ()=>subscription.unsubscribe()
  },[])
  if(!api)return <Access><h1>Configuración pendiente</h1><p className="muted">Configura la conexión a Supabase para acceder al panel de pedidos.</p></Access>
  if(session===undefined)return <Access><p>Iniciando…</p></Access>
  if(!session)return <Login/>
  return <Workspace key={session.user.id} session={session}/>
}
createRoot(document.getElementById('root')!).render(<App/>)
if(import.meta.env.PROD&&'serviceWorker' in navigator)void navigator.serviceWorker.register('/sw.js').catch(console.error)
