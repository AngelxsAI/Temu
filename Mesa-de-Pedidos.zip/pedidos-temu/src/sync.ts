import {useCallback,useEffect,useMemo,useRef,useState} from 'react'
import {createClient} from '@supabase/supabase-js'
import {openDB} from 'idb'
import {project} from './domain.ts'
import type {Batch,Role,Row} from './domain.ts'

const url=import.meta.env.VITE_SUPABASE_URL
const key=import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY
export const api=url&&key ? createClient(url,key,{auth:{autoRefreshToken:true,persistSession:true,detectSessionInUrl:false}}) : undefined
type Cache = {rows:Row[];queue:Batch[];role?:Role;verifiedAt?:number}
const empty:Cache={rows:[],queue:[]}
let database: ReturnType<typeof openDB>|undefined
function db() {
  return database??=openDB('mesa-pedidos-v1',1,{upgrade(instance){instance.createObjectStore('accounts')}})
}
async function read(uid:string):Promise<Cache> { return (await (await db()).get('accounts',uid))??empty }
async function write(uid:string,update:(old:Cache)=>Cache) {
  const tx=(await db()).transaction('accounts','readwrite')
  const value=update((await tx.store.get(uid))??empty)
  await tx.store.put(value,uid)
  await tx.done
  return value
}
export function errorText(error:unknown) {
  if(error&&typeof error==='object'&&'message' in error)return String(error.message)
  return String(error)
}
export async function clearCache(uid:string) { await (await db()).delete('accounts',uid) }

export function useOrders(uid:string) {
  const [cache,setCache]=useState<Cache>(empty)
  const [ready,setReady]=useState(false)
  const [busy,setBusy]=useState(false)
  const [error,setError]=useState('')
  const [online,setOnline]=useState(navigator.onLine)
  const running=useRef(false)
  const alive=useRef(true)
  const refresh=useCallback(async()=>{
    if(!api||!navigator.onLine||running.current) return
    running.current=true
    setBusy(true)
    try {
      const client=api
      const work=async()=>{
        const {data:role,error:roleError}=await client.rpc('staff_role')
        if(roleError) throw roleError
        if(role!=='pedidos'&&role!=='compras') {
          const value=await write(uid,current=>({...current,rows:[],role:undefined,verifiedAt:undefined}))
          if(alive.current){setCache(value);setError('Esta cuenta no está autorizada.')}
          return
        }
        const authorized=await write(uid,current=>({...current,role,verifiedAt:Date.now()}))
        if(alive.current) setCache(authorized)
        let blocked=''
        const confirmed=new Set<string>()
        for(const batch of (await read(uid)).queue) {
          if(!alive.current) return
          try {
            for(const upload of batch.uploads) {
              const {error:uploadError}=await client.storage.from('pedido-fotos').upload(upload.path,upload.file,{contentType:upload.file.type})
              if(uploadError&&String(uploadError.statusCode)!=='409') throw uploadError
            }
            const {error:opError}=await client.rpc('apply_operations',{ops:batch.ops})
            if(opError) throw opError
            confirmed.add(batch.ops[0].op)
          } catch(error) {
            blocked=errorText(error)
            break
          }
        }
        const remote:Row[]=[]
        let cursor=''
        while(true) {
          let query=client.from('records').select('*').order('id').limit(500)
          if(cursor) query=query.gt('id',cursor)
          const {data,error:listError}=await query
          if(listError) throw listError
          remote.push(...data as Row[])
          if(data.length<500) break
          cursor=data[data.length-1].id
        }
        if(!alive.current) return
        const value=await write(uid,current=>({...current,rows:remote,queue:current.queue.filter(entry=>!confirmed.has(entry.ops[0].op)),role,verifiedAt:Date.now()}))
        setCache(value)
        setError(blocked.startsWith('CONFLICT:')?'Otro dispositivo cambió este registro. Los cambios locales siguen guardados.':blocked)
      }
      if(navigator.locks) await navigator.locks.request('pedidos-sync-'+uid,{ifAvailable:true},async lock=>{if(lock&&alive.current) await work()})
      else await work()
    } catch(error) {
      if(alive.current) {
        setCache(await read(uid))
        setError(errorText(error))
      }
    } finally {
      running.current=false
      if(alive.current){setBusy(false);setReady(true)}
    }
  },[uid])
  useEffect(()=>{
    alive.current=true
    void read(uid).then(value=>{if(alive.current){setCache(value);setReady(true);void refresh()}}).catch(()=>{setError('No se pudo abrir el almacenamiento del dispositivo.');setReady(true)})
    const connect=()=>{setOnline(navigator.onLine);void refresh()}
    const foreground=()=>{if(document.visibilityState==='visible')void refresh()}
    window.addEventListener('online',connect)
    window.addEventListener('offline',connect)
    document.addEventListener('visibilitychange',foreground)
    const timer=window.setInterval(foreground,12000)
    return ()=>{
      alive.current=false
      window.clearInterval(timer)
      window.removeEventListener('online',connect)
      window.removeEventListener('offline',connect)
      document.removeEventListener('visibilitychange',foreground)
    }
  },[uid,refresh])
  const save=async(batch:Batch)=>{
    if(!cache.role) throw new Error('La cuenta aún no se ha autorizado.')
    if(!batch.ops.length||batch.ops.length>200) throw new Error('Guarda entre 1 y 200 cambios por vez.')
    const value=await write(uid,current=>({...current,queue:[...current.queue,batch]}))
    setCache(value)
    void refresh()
  }
  const discard=async()=>{
    const reset=async()=>{setCache(await write(uid,current=>({...current,queue:[]})));setError('')}
    if(navigator.locks) await navigator.locks.request('pedidos-sync-'+uid,reset)
    else await reset()
    void refresh()
  }
  const rows=useMemo(()=>project(cache.rows,cache.queue),[cache.rows,cache.queue])
  return {rows,remote:cache.rows,queue:cache.queue,role:cache.verifiedAt&&Date.now()-cache.verifiedAt<7*86400000?cache.role:undefined,ready,busy,error,online,refresh,save,discard}
}
export type Store = ReturnType<typeof useOrders>
export async function prepareUploads(id:string, files:File[]):Promise<Batch['uploads']> {
  return Promise.all(files.map(async file=>{
    if(file.size>20*1024*1024) throw new Error('Selecciona imágenes de hasta 20 MB.')
    if(!['image/jpeg','image/png','image/webp'].includes(file.type)) throw new Error('Usa fotos JPEG, PNG o WebP.')
    const image=await createImageBitmap(file)
    try {
      const ratio=Math.min(1,1440/Math.max(image.width,image.height))
      const canvas=document.createElement('canvas')
      canvas.width=Math.max(1,Math.round(image.width*ratio))
      canvas.height=Math.max(1,Math.round(image.height*ratio))
      canvas.getContext('2d')!.drawImage(image,0,0,canvas.width,canvas.height)
      const blob=await new Promise<Blob|null>(resolve=>canvas.toBlob(resolve,'image/jpeg',.82))
      if(!blob||blob.size>2097152) throw new Error('No se pudo reducir la imagen a 2 MB.')
      return {path:id+'/'+crypto.randomUUID()+'.jpg',file:blob}
    } finally {image.close()}
  }))
}
