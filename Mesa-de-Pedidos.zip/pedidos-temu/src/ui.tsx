import {useEffect,useId,useRef,useState} from 'react'
import type {ButtonHTMLAttributes,ReactNode} from 'react'
import {AlertCircle, Camera, Clipboard, ExternalLink, ImageOff, Package, Plus, X} from 'lucide-react'
import {api,errorText} from './sync.ts'
import {labels,issues,moneyInput} from './domain.ts'
import type {Product,Status,Upload,Variant} from './domain.ts'

export function Button({children,variant='secondary',className='',type='button',...props}:ButtonHTMLAttributes<HTMLButtonElement>&{variant?:'primary'|'secondary'|'plain'|'danger'}) {
  return <button type={type} className={'button '+variant+' '+className} {...props}>{children}</button>
}
export function Field({label,children,wide=false}: {label:string;children:ReactNode;wide?:boolean}) {
  return <label className={'field'+(wide?' wide':'')}><span>{label}</span>{children}</label>
}
export function Empty({title='Todavía no hay registros',children}:{title?:string;children?:ReactNode}) {
  return <div className="empty"><Package size={30}/><strong>{title}</strong>{children}</div>
}
export function ErrorNote({children}:{children:ReactNode}) {
  return <div className="error" role="alert"><AlertCircle size={17}/><span>{children}</span></div>
}
export function Chip({status}:{status:Status}) {
  return <span className={'chip '+(issues.includes(status)?'bad':status==='pendiente'?'waiting':'')}>{labels[status]}</span>
}
export function Modal({title,children,onClose}:{title:string;children:ReactNode;onClose:()=>void}) {
  const ref=useRef<HTMLDialogElement>(null)
  const id=useId()
  useEffect(()=>{ref.current?.showModal()},[])
  return <dialog ref={ref} aria-labelledby={id} onCancel={event=>{event.preventDefault();onClose()}}>
    <div className="modal-head"><h2 id={id}>{title}</h2><Button variant="plain" onClick={onClose} aria-label="Cerrar"><X size={22}/></Button></div>
    <div className="modal-body">{children}</div>
  </dialog>
}
export function ProductFields({value,set,disabled=false}:{value:Product;set:(v:Product)=>void;disabled?:boolean}) {
  function updateVariant(index:number,patch:Partial<Variant>) {
    set({...value,variants:value.variants.map((row,i)=>i===index?{...row,...patch}:row)})
  }
  return <>
    <div className="form-grid">
      <Field label="Enlace original de Temu" wide><input disabled={disabled} type="url" required maxLength={3000} value={value.url} onChange={e=>set({...value,url:e.target.value})} placeholder="https://www.temu.com/…"/></Field>
      <Field label="Nombre del producto"><input maxLength={160} value={value.name} onChange={e=>set({...value,name:e.target.value})} placeholder="Ej. Camiseta de flores"/></Field>
      <div className="form-grid"><Field label="Cantidad"><input disabled={disabled} type="number" min="1" max="10000" required value={value.qty||''} onChange={e=>set({...value,qty:Number(e.target.value)})}/></Field>
      <Field label="Categoría"><select disabled={disabled} value={value.category} onChange={e=>set({...value,category:e.target.value as Product['category']})}><option value="otros">Otros</option><option value="ropa">Ropa</option></select></Field></div>
    </div>
    <fieldset disabled={disabled} className="variants">
      <legend>Variantes</legend>
      <div className="actions">{['Talla','Color','Diseño','Modelo'].filter(label=>!value.variants.some(v=>v.label===label)).map(label=><Button key={label} onClick={()=>set({...value,variants:[...value.variants,{label,value:''}]})}><Plus size={14}/>{label}</Button>)}<Button onClick={()=>set({...value,variants:[...value.variants,{label:'',value:''}]})}><Plus size={14}/>Otra variante</Button></div>
      {value.variants.map((row,index)=><div className="variant-row" key={index}>
        <input aria-label="Nombre de variante" required maxLength={80} placeholder="Ej. Material" value={row.label} onChange={e=>updateVariant(index,{label:e.target.value})}/>
        <input aria-label={'Valor de '+(row.label||'variante')} required maxLength={300} placeholder="Ej. Algodón" value={row.value} onChange={e=>updateVariant(index,{value:e.target.value})}/>
        <Button variant="plain" aria-label="Quitar variante" onClick={()=>set({...value,variants:value.variants.filter((_,i)=>i!==index)})}><X size={17}/></Button>
      </div>)}
      <Field label="Variantes requeridas para comprar"><input value={value.required.join(',')} onChange={e=>set({...value,required:e.target.value.split(',')})} placeholder="Ej. Talla, Color"/></Field>
    </fieldset>
    <Field label="Notas especiales" wide><textarea maxLength={3000} value={value.notes} onChange={e=>set({...value,notes:e.target.value})}/></Field>
  </>
}
export function FilePicker({files,set,label='Adjuntar capturas o fotos'}:{files:File[];set:(files:File[])=>void;label?:string}) {
  return <label className="file-picker"><Camera size={19}/><span>{label}{files.length?' · '+files.length+' seleccionadas':''}</span><input type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={e=>set(Array.from(e.target.files??[]))}/></label>
}
export function Photo({path,uploads=[]}:{path:string;uploads?:Upload[]}) {
  const [url,setUrl]=useState('')
  const local=uploads.find(upload=>upload.path===path)?.file
  useEffect(()=>{
    let alive=true
    let objectUrl=''
    if(local){objectUrl=URL.createObjectURL(local);setUrl(objectUrl)}
    else void api?.storage.from('pedido-fotos').createSignedUrl(path,600).then(({data})=>{if(alive)setUrl(data?.signedUrl??'')})
    return ()=>{alive=false;if(objectUrl) URL.revokeObjectURL(objectUrl)}
  },[path,local])
  return url?<a href={url} target="_blank" rel="noreferrer"><img className="photo" src={url} alt="Evidencia del artículo" loading="lazy"/></a>:<span className="photo no-photo" title="Imagen no disponible sin conexión"><ImageOff size={20}/></span>
}
export function Amount({label,value,onChange,placeholder}:{label:string;value:string;onChange:(s:string)=>void;placeholder?:number}) {
  return <Field label={label}><div className="currency-input"><span>$</span><input inputMode="decimal" value={value} maxLength={12} placeholder={moneyInput(placeholder)} onChange={e=>onChange(e.target.value)}/></div></Field>
}
export function Message({text,onCopy}:{text:string;onCopy:(s:string)=>void}) {
  const [error,setError]=useState('')
  return <>
    <textarea className="message" readOnly aria-label="Texto preparado" value={text||'No hay artículos para esta selección.'} />
    {error&&<ErrorNote>{error}</ErrorNote>}
    <div className="actions"><Button disabled={!text} variant="primary" onClick={()=>onCopy(text)}><Clipboard size={17}/>Copiar texto</Button>
      <Button disabled={!text} onClick={async()=>{
        try {
          if(navigator.share) await navigator.share({text})
          else window.open('https://wa.me/?text='+encodeURIComponent(text),'_blank','noopener,noreferrer')
        } catch(e){if(!(e instanceof DOMException&&e.name==='AbortError'))setError(errorText(e))}
      }}><ExternalLink size={17}/>Compartir por WhatsApp</Button></div>
  </>
}
export function download(filename:string,content:string,type:string) {
  const url=URL.createObjectURL(new Blob([content],{type}))
  const a=document.createElement('a')
  a.href=url;a.download=filename;a.click()
  window.setTimeout(()=>URL.revokeObjectURL(url),10000)
}
