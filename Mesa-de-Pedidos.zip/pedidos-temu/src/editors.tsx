import {useEffect,useState} from 'react'
import type {FormEvent,ReactNode} from 'react'
import {ArrowUpRight, Plus, Save} from 'lucide-react'
import {blankItem,byKind,defaultSettings,fold,labels,lotLabels,missingVariants,money,moneyInput,operation,settingsId,suggestPrice,temuUrl,toCents,today} from './domain.ts'
import type {Batch,Client,Item,Kind,Lot,Op,Pricing,Product,RecordData,Row,Status} from './domain.ts'
import {errorText,prepareUploads} from './sync.ts'
import type {Store} from './sync.ts'
import {Amount,Button,ErrorNote,Field,FilePicker,Modal,Photo,ProductFields} from './ui.tsx'

export function useSubmit(save:Store['save'],done:()=>void) {
  const [error,setError]=useState('')
  const [busy,setBusy]=useState(false)
  return {error,busy,submit:async(build:()=>Batch|Promise<Batch>)=>{
    if(busy)return
    setBusy(true);setError('')
    try {await save(await build());done()} catch(error){setError(errorText(error))}
    finally {setBusy(false)}
  }}
}
export function SaveBar({busy,error,text='Guardar cambios'}:{busy:boolean;error:string;text?:string}) {
  return <>{error&&<ErrorNote>{error}</ErrorNote>}<div className="actions"><Button type="submit" variant="primary" disabled={busy}><Save size={17}/>{busy?'Guardando…':text}</Button></div></>
}
export function useDraft<T>(key:string,initial:T) {
  const [value,set]=useState<T>(()=>{try{return JSON.parse(sessionStorage.getItem(key)??'null')??initial}catch{return initial}})
  useEffect(()=>{try {sessionStorage.setItem(key,JSON.stringify(value))}catch{}},[key,value])
  return [value,set,()=>sessionStorage.removeItem(key)] as const
}
export function cleanProduct(value:Product):Product {
  const clean:Product={name:value.name.trim(),url:value.url.trim(),qty:value.qty,category:value.category,
    variants:value.variants.map(v=>({label:v.label.trim(),value:v.value.trim()})),required:value.required.map(s=>s.trim()).filter(Boolean),notes:value.notes.trim()}
  if(!temuUrl(clean.url))throw new Error('Pega un enlace HTTPS original de Temu.')
  if(!Number.isInteger(clean.qty)||clean.qty<1||clean.qty>10000)throw new Error('Confirma la cantidad.')
  if(clean.variants.some(v=>!v.label||!v.value)||new Set(clean.variants.map(v=>fold(v.label))).size!==clean.variants.length)throw new Error('Completa las variantes y evita nombres repetidos.')
  return clean
}
export function ItemEditor({uid,store,row,initial,clientId,onClose}:{uid:string;store:Store;row?:Row<'item'>;initial?:Item;clientId?:string;onClose:()=>void}) {
  const [value,set,clear]=useDraft(uid+'-item-'+(row?.id??'new')+'-'+(row?.version??'0'),row?.data??initial??{...blankItem,client:clientId??''})
  const [files,setFiles]=useState<File[]>([])
  const [clientName,setClientName]=useState('')
  const [create,setCreate]=useState(false)
  const [repeated,setRepeated]=useState(false)
  const [stay,setStay]=useState(false)
  const [lastClient,setLastClient]=useState(value.client)
  const clients=byKind(store.rows,'client')
  const templates=byKind(store.rows,'template')
  const duplicate=byKind(store.rows,'item').some(item=>item.id!==row?.id&&item.data.url===value.url.trim())
  const immutable=!!row&&store.role==='pedidos'&&!['pendiente','problema','agotado'].includes(row.data.status)
  const incomplete=missingVariants(value)
  const s=useSubmit(store.save,()=>{clear();if(stay){set({...blankItem,client:lastClient});setFiles([]);setCreate(false);setClientName('');setRepeated(false)}else onClose()})
  return <Modal title={row?'Editar artículo':'Nuevo artículo'} onClose={()=>{if(!files.length||confirm('Las fotos seleccionadas se perderán al cerrar. ¿Cerrar?'))onClose()}}>
    <form onSubmit={event=>{event.preventDefault();void s.submit(async()=>{
      const ops:Op[]=[]
      let client=value.client
      if(create) {
        const name=clientName.trim()
        if(!name)throw new Error('Escribe el nombre del cliente.')
        if(clients.some(r=>fold(r.data.name)===fold(name)))throw new Error('Ya hay un cliente con ese nombre. Selecciónalo de la lista.')
        const add=operation('client',{name,phone:'',notes:''})
        ops.push(add);client=add.id
      }
      if(!client)throw new Error('Selecciona un cliente.')
      if(duplicate&&!repeated&&row?.data.url!==value.url.trim())throw new Error('Confirma que el enlace repetido corresponde a otro encargo.')
      const id=row?.id??crypto.randomUUID()
      if(files.length+value.files.length>12)throw new Error('Se permiten hasta 12 adjuntos por artículo.')
      const uploads=await prepareUploads(id,files)
      ops.push(operation('item',{...value,...cleanProduct(value),client,files:[...value.files,...uploads.map(u=>u.path)]},row,undefined,id))
      setLastClient(client)
      return {ops,uploads}
    })}}>
      <div className="form-grid"><Field label="Cliente"><select disabled={immutable||create} required={!create} value={value.client} onChange={e=>set({...value,client:e.target.value})}>
        <option value="">Seleccionar cliente</option>{clients.map(r=><option key={r.id} value={r.id}>{r.data.name}</option>)}</select></Field>
        {!immutable&&<Button className="align-end" onClick={()=>setCreate(!create)}><Plus size={16}/>{create?'Elegir cliente existente':'Crear cliente aquí'}</Button>}
        {create&&<Field label="Nombre del nuevo cliente" wide><input required maxLength={160} value={clientName} onChange={e=>setClientName(e.target.value)}/></Field>}
        {!row&&templates.length>0&&<Field label="Usar plantilla" wide><select defaultValue="" onChange={e=>{const t=templates.find(r=>r.id===e.target.value);if(t)set({...value,...t.data})}}><option value="">Elegir plantilla</option>{templates.map(t=><option key={t.id} value={t.id}>{t.data.name}</option>)}</select></Field>}
      </div>
      <ProductFields value={value} set={p=>set({...value,...p})} disabled={immutable}/>
      {incomplete.length>0&&<p className="notice">Completa antes de comprar: {incomplete.join(', ')}.</p>}
      {duplicate&&row?.data.url!==value.url.trim()&&<label className="notice check"><input type="checkbox" checked={repeated} onChange={e=>setRepeated(e.target.checked)}/>El enlace ya existe. Confirmo que es otro encargo.</label>}
      {value.files.length>0&&<div className="photos">{value.files.map(path=><Photo path={path} key={path} uploads={store.queue.flatMap(x=>x.uploads)}/>)}</div>}
      <FilePicker files={files} set={setFiles}/>
      {!row&&<label className="check"><input type="checkbox" checked={stay} onChange={e=>setStay(e.target.checked)}/>Seguir agregando artículos</label>}
      <SaveBar {...s} text={row?'Guardar cambios':'Guardar artículo'}/>
    </form>
  </Modal>
}
export function ClientEditor({store,row,onClose}:{store:Store;row?:Row<'client'>;onClose:()=>void}) {
  const [value,set]=useState<Client>(row?.data??{name:'',phone:'',notes:''})
  const [fee,setFee]=useState(moneyInput(value.commission))
  const [confirmed,confirmDuplicate]=useState(false)
  const duplicates=byKind(store.rows,'client').filter(r=>r.id!==row?.id&&(fold(r.data.name)===fold(value.name)||(value.phone.trim()&&r.data.phone.replace(/\D/g,'')===value.phone.replace(/\D/g,''))))
  const s=useSubmit(store.save,onClose)
  return <Modal title={row?'Editar cliente':'Nuevo cliente'} onClose={onClose}>
    <form onSubmit={e=>{e.preventDefault();void s.submit(()=>{
      if(!value.name.trim())throw new Error('Escribe un nombre.')
      if(duplicates.length&&!confirmed)throw new Error('Confirma el posible duplicado.')
      const next={...value,name:value.name.trim(),commission:store.role==='compras'?toCents(fee):value.commission}
      return {ops:[operation('client',next,row)],uploads:[]}
    })}}>
      <Field label="Nombre o apodo"><input required maxLength={160} value={value.name} onChange={e=>{set({...value,name:e.target.value});confirmDuplicate(false)}}/></Field>
      <Field label="Teléfono (opcional)"><input type="tel" maxLength={40} value={value.phone} onChange={e=>{set({...value,phone:e.target.value});confirmDuplicate(false)}}/></Field>
      <Field label="Notas"><textarea maxLength={3000} value={value.notes} onChange={e=>set({...value,notes:e.target.value})}/></Field>
      {store.role==='compras'&&<Amount label="Comisión especial por unidad (opcional)" value={fee} onChange={setFee}/>}
      {duplicates.length>0&&<label className="check notice"><input type="checkbox" checked={confirmed} onChange={e=>confirmDuplicate(e.target.checked)}/>Posible duplicado: {duplicates.map(r=>r.data.name).join(', ')}. Confirmo que es otro cliente.</label>}
      <SaveBar {...s}/>
    </form>
  </Modal>
}
const priceKeys={original:'Precio original unitario',cost:'Costo real unitario',commission:'Comisión unitaria',extra:'Gasto adicional unitario',discount:'Descuento al cliente por unidad',final:'Precio final manual por unidad'} as const
type PriceKey=keyof typeof priceKeys
export function PriceEditor({store,row,onClose}:{store:Store;row:Row<'item'>;onClose:()=>void}) {
  const [inputs,set]=useState(()=>Object.fromEntries(Object.keys(priceKeys).map(key=>[key,moneyInput(row.data[key as PriceKey])])) as Record<PriceKey,string>)
  const [manual,setManual]=useState(row.data.manual??false)
  const settings=byKind(store.rows,'settings')[0]?.data??defaultSettings
  const client=byKind(store.rows,'client').find(c=>c.id===row.data.client)?.data
  const build=()=>{
    const price=Object.fromEntries(Object.keys(priceKeys).map(key=>[key,toCents(inputs[key as PriceKey])])) as Pricing
    return {...price,manual,final:manual?price.final:suggestPrice(price,row.data,settings,client)}
  }
  let value:number|undefined
  try{value=build().final}catch{}
  const s=useSubmit(store.save,onClose)
  return <Modal title="Establecer precio" onClose={onClose}>
    <form onSubmit={e=>{e.preventDefault();void s.submit(()=>{
      const p=build()
      if(p.final===undefined)throw new Error('Ingresa el costo, precio original o precio manual.')
      return {ops:[operation('item',{...row.data,...p},row)],uploads:[]}
    })}}>
      <strong>{row.data.name||'Artículo de Temu'} · {row.data.qty} unidades</strong>
      <div className="form-grid">{(Object.keys(priceKeys) as PriceKey[]).filter(key=>key!=='final'||manual).map(key=><Amount key={key} label={priceKeys[key]} value={inputs[key]} placeholder={key==='commission'?client?.commission??(row.data.category==='ropa'?settings.clothing:settings.other):undefined} onChange={v=>set({...inputs,[key]:v})}/>)}</div>
      <label className="check"><input type="checkbox" checked={manual} onChange={e=>setManual(e.target.checked)}/>Usar precio manual</label>
      <div className="notice">Precio unitario <strong>{value===undefined?'Por calcular':money(value)}</strong> · Subtotal <strong>{value===undefined?'—':money(value*row.data.qty)}</strong></div>
      <SaveBar {...s} text="Publicar precio"/>
    </form>
  </Modal>
}
export function ReviewEditor({store,row,onClose}:{store:Store;row:Row<'item'>;onClose:()=>void}) {
  const [status,setStatus]=useState<Status>(row.data.status)
  const [received,setReceived]=useState(row.data.received?.toString()??'')
  const [notes,setNotes]=useState('')
  const [files,setFiles]=useState<File[]>([])
  const s=useSubmit(store.save,onClose)
  return <Modal title="Revisar artículo y entrega" onClose={()=>{if((!notes&&!files.length)||confirm('¿Cerrar la revisión sin guardar?'))onClose()}}>
    <form onSubmit={e=>{e.preventDefault();void s.submit(async()=>{
      const count=received===''?undefined:Number(received)
      const needsNote=['variante_incorrecta','defectuoso','incompleto','no_recibido','en_devolucion','problema','reembolsado'].includes(status)
      if(needsNote&&!notes.trim())throw new Error('Describe el problema o el reembolso.')
      if(['correcto','entregado'].includes(status)&&count!==row.data.qty)throw new Error('Confirma la cantidad completa.')
      if(status==='incompleto'&&(count===undefined||count>=row.data.qty))throw new Error('Registra una cantidad inferior a la esperada.')
      if(status==='no_recibido'&&count!==0)throw new Error('Registra cero unidades recibidas.')
      if(status==='entregado'&&!confirm('¿Confirmas la entrega al cliente?'))throw new Error('La entrega quedó sin confirmar.')
      const uploads=await prepareUploads(row.id,files)
      if(uploads.length>12)throw new Error('Adjunta hasta 12 fotos.')
      const ops=[operation('item',{...row.data,status,received:count},row)]
      if(notes.trim()||uploads.length)ops.push(operation('incident',{item:row.id,status,received:count,notes:notes.trim()||'Evidencia fotográfica',date:today(),files:uploads.map(u=>u.path)}))
      return {ops,uploads}
    })}}>
      <strong>{row.data.name||'Producto de Temu'}</strong>
      <p>Esperadas: {row.data.qty} · {row.data.variants.map(v=>v.label+': '+v.value).join(' · ')}</p>
      {row.data.files.length>0&&<div className="photos">{row.data.files.map(path=><Photo key={path} path={path} uploads={store.queue.flatMap(b=>b.uploads)}/>)}</div>}
      <div className="form-grid"><Field label="Cantidad recibida"><input type="number" min="0" max={row.data.qty} value={received} onChange={e=>setReceived(e.target.value)}/></Field>
      <Field label="Estado del artículo"><select value={status} onChange={e=>setStatus(e.target.value as Status)}>{Object.entries(labels).map(([key,label])=><option value={key} key={key}>{label}</option>)}</select></Field></div>
      {received!==''&&Number(received)<row.data.qty&&<p className="notice">Faltan {row.data.qty-Number(received)} unidades.</p>}
      <Field label="Observación de la revisión"><textarea maxLength={3000} value={notes} onChange={e=>setNotes(e.target.value)}/></Field>
      <FilePicker files={files} set={setFiles} label="Adjuntar fotos de lo recibido"/>
      <SaveBar {...s}/>
    </form>
  </Modal>
}
export function LotEditor({store,row,onClose}:{store:Store;row?:Row<'lot'>;onClose:()=>void}) {
  const [value,set]=useState<Lot>(row?.data??{name:'',date:today(),tracking:'',status:'abierto',notes:''})
  const s=useSubmit(store.save,onClose)
  return <Modal title={row?'Editar lote':'Nuevo lote'} onClose={onClose}><form onSubmit={e=>{e.preventDefault();void s.submit(()=>({ops:[operation('lot',value,row)],uploads:[]}))}}>
    <Field label="Identificador del lote"><input required maxLength={160} value={value.name} onChange={e=>set({...value,name:e.target.value})}/></Field>
    <div className="form-grid"><Field label="Fecha"><input required type="date" value={value.date} onChange={e=>set({...value,date:e.target.value})}/></Field>
    <Field label="Estado del envío"><select value={value.status} onChange={e=>set({...value,status:e.target.value as Lot['status']})}>{Object.entries(lotLabels).map(([key,label])=><option value={key} key={key}>{label}</option>)}</select></Field></div>
    <Field label="Número de seguimiento"><input maxLength={140} value={value.tracking} onChange={e=>set({...value,tracking:e.target.value})}/></Field>
    <Field label="Notas"><textarea maxLength={3000} value={value.notes} onChange={e=>set({...value,notes:e.target.value})}/></Field><SaveBar {...s}/>
  </form></Modal>
}
export function MovementEditor({store,kind,target,onClose}:{store:Store;kind:'payment'|'refund';target:string;onClose:()=>void}) {
  const [type,setType]=useState(kind==='payment'?'pago':'temu')
  const [date,setDate]=useState(today())
  const [amount,setAmount]=useState('')
  const [notes,setNotes]=useState('')
  const s=useSubmit(store.save,onClose)
  return <Modal title={kind==='payment'?'Registrar cobro':'Registrar reembolso'} onClose={onClose}><form onSubmit={e=>{e.preventDefault();void s.submit(()=>{
    const cents=toCents(amount)
    if(!cents)throw new Error('Escribe un importe mayor que cero.')
    return {ops:[kind==='payment'?operation('payment',{client:target,type:type as RecordData['payment']['type'],date,notes,amount:cents}):operation('refund',{item:target,type:type as RecordData['refund']['type'],date,notes,amount:cents})],uploads:[]}
  })}}>
    <div className="form-grid"><Field label="Tipo"><select value={type} onChange={e=>setType(e.target.value)}>{kind==='payment'?<><option value="pago">Pago</option><option value="anticipo">Anticipo</option></>:<><option value="temu">Recibido de Temu</option><option value="cliente">Devuelto al cliente</option></>}</select></Field>
    <Field label="Fecha"><input required type="date" value={date} onChange={e=>setDate(e.target.value)}/></Field></div>
    <Amount label="Importe total" value={amount} onChange={setAmount}/><Field label="Observaciones"><textarea maxLength={3000} value={notes} onChange={e=>setNotes(e.target.value)}/></Field><SaveBar {...s}/>
  </form></Modal>
}
export function SimpleModal<K extends Kind>({title,store,kind,row,id,value,onClose,children}:{title:string;store:Store;kind:K;row?:Row<K>;id?:string;value:()=>RecordData[K];onClose:()=>void;children:ReactNode}) {
  const s=useSubmit(store.save,onClose)
  const save=(event:FormEvent)=>{event.preventDefault();void s.submit(()=>({ops:[operation(kind,value(),row,undefined,id)],uploads:[]}))}
  return <Modal title={title} onClose={onClose}><form onSubmit={save}>{children}<SaveBar {...s}/></form></Modal>
}
export function SettingsEditor({store,row,onClose}:{store:Store;row?:Row<'settings'>;onClose:()=>void}) {
  const settings=row?.data??defaultSettings
  const [clothing,setClothing]=useState(moneyInput(settings.clothing))
  const [other,setOther]=useState(moneyInput(settings.other))
  const [rounding,setRounding]=useState(moneyInput(settings.rounding))
  return <SimpleModal title="Reglas de precios" store={store} kind="settings" row={row} id={settingsId} onClose={onClose} value={()=>{
    const step=toCents(rounding), c=toCents(clothing), o=toCents(other)
    if(!step||step>10000||c===undefined||o===undefined||c>1000000||o>1000000)throw new Error('Completa las comisiones y usa un redondeo entre $0.01 y $100.')
    return {clothing:c,other:o,rounding:step}
  }}>
    <Amount label="Comisión de ropa por unidad" value={clothing} onChange={setClothing}/>
    <Amount label="Comisión de otros artículos por unidad" value={other} onChange={setOther}/>
    <Amount label="Redondear hacia arriba al siguiente múltiplo de" value={rounding} onChange={setRounding}/>
    <p className="muted">Estas reglas se aplican cuando calculas un precio. Los precios publicados conservan su importe.</p>
  </SimpleModal>
}
export function TemuLink({url}:{url:string}) {
  return <a className="button primary" href={url} target="_blank" rel="noreferrer"><ArrowUpRight size={16}/>Abrir en Temu</a>
}
