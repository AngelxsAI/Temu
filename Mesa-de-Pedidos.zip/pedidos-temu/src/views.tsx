import {useEffect,useState} from 'react'
import {ArrowDownToLine, ArrowRight, Clipboard, ClipboardList, CreditCard, History, PackageCheck, Plus, Search, Truck, Users, Wallet} from 'lucide-react'
import {blankItem,byKind,csv,fold,issues,labels,localDate,lotLabels,missingVariants,money,nameOf,operation,parseMessage,priceList,purchaseList,settingsId,purchased,reviewed,specs,temuUrl,today} from './domain.ts'
import type {Candidate,Item,Kind,Op,Row,Status} from './domain.ts'
import {api,errorText} from './sync.ts'
import type {Store} from './sync.ts'
import {Button,Chip,download,Empty,ErrorNote,Field,Message,Modal,Photo} from './ui.tsx'
import {cleanProduct,SaveBar,TemuLink,useSubmit} from './editors.tsx'

export type Screen='Inicio'|'Artículos'|'Clientes'|'Preparar compra'|'Paquetes'|'Cobros'|'Ajustes'
export type Editor='item'|'client'|'lot'|'price'|'review'|'payment'|'refund'|'settings'|'import'|'messages'|'history'|'duplicate'|'merge'
export type Open=(editor:Editor,id?:string)=>void
export type Copy=(text:string)=>void
export function ItemCard({row,store,open,copy,selected,onSelect}:{row:Row<'item'>;store:Store;open:Open;copy:Copy;selected?:boolean;onSelect?:()=>void}) {
  const p=row.data
  const client=nameOf(p.client,byKind(store.rows,'client'))
  const lot=byKind(store.rows,'lot').find(r=>r.id===p.lot)
  return <article className="card item-card">
    <div className="card-top">
      {p.files[0]&&<Photo path={p.files[0]} uploads={store.queue.flatMap(b=>b.uploads)}/>}
      <div className="grow"><p className="muted small">{client}{lot?' · '+lot.data.name:''}</p><h3>{p.name||'Artículo de Temu'}</h3></div><Chip status={p.status}/>
      {onSelect&&<input className="select-item" type="checkbox" aria-label={'Seleccionar '+(p.name||'artículo')} checked={selected} onChange={onSelect}/>}
    </div>
    <div className="tags"><span>{p.qty} {p.qty===1?'unidad':'unidades'}</span>{p.variants.map(v=><span key={v.label}>{v.label}: {v.value}</span>)}</div>
    {missingVariants(p).length>0&&<p className="notice">Variantes pendientes: {missingVariants(p).join(', ')}</p>}
    <div className="card-top price-row"><span>{p.final===undefined?'Precio pendiente':money(p.final)+' por unidad'}</span>{p.final!==undefined&&<strong>{money(p.final*p.qty)}</strong>}</div>
    {p.notes&&<p className="muted wrap">{p.notes}</p>}
    <div className="actions"><Button onClick={()=>open('item',row.id)}>Editar</Button>{store.role==='compras'&&<><Button onClick={()=>open('price',row.id)}>Precio</Button><Button onClick={()=>open('review',row.id)}>Revisar</Button></>}
      <Button onClick={()=>open('history',row.id)}><History size={15}/>Historial</Button>
      <Button onClick={()=>open('duplicate',row.id)}>Duplicar</Button>
      <Button onClick={()=>copy(purchaseList([row],byKind(store.rows,'client')))}>Copiar ficha</Button></div>
  </article>
}
function count(items:Row<'item'>[],states:Status[]){return items.filter(r=>states.includes(r.data.status)).length}
function stats(store:Store,items:Row<'item'>[],client?:string,month?:string) {
  const payments=byKind(store.rows,'payment').filter(r=>(!client||r.data.client===client)&&(!month||r.data.date.startsWith(month)))
  const refunds=byKind(store.rows,'refund').filter(r=>!month||r.data.date.startsWith(month))
  return totalsSafe(items,payments,refunds)
}
import {totals as totalsSafe} from './domain.ts'
export function Dashboard({store,open,go}:{store:Store;open:Open;go:(s:Screen)=>void}) {
  const [month,setMonth]=useState('')
  const [client,setClient]=useState('')
  const [lot,setLot]=useState('')
  const [status,setStatus]=useState('')
  const clients=byKind(store.rows,'client')
  const items=byKind(store.rows,'item')
  const filtered=items.filter(r=>(!month||localDate(r.created_at).startsWith(month))&&(!client||r.data.client===client)&&(!lot||r.data.lot===lot)&&(!status||r.data.status===status))
  const financialItems=[...items,...byKind(store.rows,'item',true)]
  const financial=stats(store,financialItems.filter(r=>(!month||localDate(r.created_at).startsWith(month))&&(!client||r.data.client===client)),client||undefined,month)
  const active=new Set(filtered.filter(r=>r.data.status!=='entregado'&&r.data.status!=='agotado').map(r=>r.data.client)).size
  const metrics=[
    {label:'Pendientes de compra',value:count(filtered,['pendiente']),icon:ClipboardList,screen:'Preparar compra'},
    {label:'Clientes activos',value:active,icon:Users,screen:'Clientes'},
    {label:'Comprados',value:count(filtered,purchased),icon:Truck,screen:'Artículos'},
    {label:'Recibidos',value:filtered.filter(r=>reviewed.includes(r.data.status)&&r.data.status!=='no_recibido'&&(r.data.received??0)>0).length,icon:PackageCheck,screen:'Paquetes'},
    {label:'Con incidencias',value:count(filtered,issues),icon:PackageCheck,screen:'Paquetes'},
    {label:'Entregados',value:count(filtered,['entregado']),icon:PackageCheck,screen:'Artículos'},
  ] as const
  return <>
    <section className="hero">
      <div><p className="eyebrow">OPERACIONES</p><h1>Panel de pedidos</h1><p>Registra encargos, prepara compras y revisa entregas desde un solo lugar.</p></div>
      <Button className="hero-button" onClick={()=>open('item')}><Plus size={19}/>Nuevo artículo</Button>
    </section>
    <div className="section-head"><h2>Actividad</h2><div className="actions"><input aria-label="Mes del panel" type="month" value={month} onChange={e=>setMonth(e.target.value)}/>{month&&<Button onClick={()=>setMonth('')}>Todo</Button>}</div></div>
    <div className="card filters"><select aria-label="Cliente del panel" value={client} onChange={e=>setClient(e.target.value)}><option value="">Todos los clientes</option>{clients.map(r=><option key={r.id} value={r.id}>{r.data.name}</option>)}</select><select aria-label="Lote del panel" value={lot} onChange={e=>setLot(e.target.value)}><option value="">Todos los lotes</option>{byKind(store.rows,'lot').map(r=><option key={r.id} value={r.id}>{r.data.name}</option>)}</select><select aria-label="Estado del panel" value={status} onChange={e=>setStatus(e.target.value)}><option value="">Todos los estados</option>{Object.entries(labels).map(([key,label])=><option value={key} key={key}>{label}</option>)}</select></div>
    <div className="metrics">{metrics.map(({label,value,icon:Icon,screen})=><button className="card metric" key={label} onClick={()=>go(screen)}><Icon size={21}/><strong>{value}</strong><span>{label}</span></button>)}</div>
    <div className="section-head"><h2>Resumen de dinero</h2><Button onClick={()=>go('Cobros')}><Wallet size={17}/>Ver cobros</Button></div>
    {(lot||status)&&<p className="muted small">El dinero se resume por cliente y mes. Los pagos no se asignan a lotes ni a estados.</p>}
    <div className="metrics financial">
      {([
        ['Vendido neto',money(financial.netSales)],['Pendiente de cobrar',money(Math.max(0,financial.due))],
        ...(store.role==='compras'?[['Ganancia estimada',money(financial.estimated)],['Ganancia real de caja',financial.missingCosts?'Costos pendientes':money(financial.real)]]:[]),
      ]).map(([label,value])=><article className="card metric" key={label}><strong>{value}</strong><span>{label}</span></article>)}
    </div>
    <div className="section-head"><h2>Artículos recientes</h2><Button onClick={()=>go('Artículos')}>Ver artículos <ArrowRight size={16}/></Button></div>
    {filtered.length===0?<Empty title="Aún no hay artículos en este período"><Button variant="primary" onClick={()=>open('item')}><Plus size={17}/>Registrar un artículo</Button></Empty>:<div className="card recent">{[...filtered].sort((a,b)=>b.created_at.localeCompare(a.created_at)).slice(0,6).map(r=><button key={r.id} onClick={()=>open('item',r.id)}><div><strong>{r.data.name||'Artículo de Temu'}</strong><p className="muted small">{nameOf(r.data.client,byKind(store.rows,'client'))}</p></div><Chip status={r.data.status}/><ArrowRight size={16}/></button>)}</div>}
  </>
}
export function Articles({store,open,copy,client,clearClient}:{store:Store;open:Open;copy:Copy;client:string;clearClient:()=>void}) {
  const [search,setSearch]=useState('')
  const [status,setStatus]=useState('')
  const [date,setDate]=useState('')
  const [lot,setLot]=useState('')
  const [selected,setSelected]=useState<string[]>([])
  const [next,setNext]=useState<Status>('comprado')
  const [assign,setAssign]=useState('')
  const [error,setError]=useState('')
  const clients=byKind(store.rows,'client')
  const lots=byKind(store.rows,'lot')
  const items=byKind(store.rows,'item').filter(({data:p,created_at})=>(!client||p.client===client)&&(!status||p.status===status)&&(!lot||p.lot===lot)&&(!date||localDate(created_at)===date)&&fold([p.name,p.url,p.notes,nameOf(p.client,clients),...p.variants.flatMap(v=>[v.label,v.value])].join(' ')).includes(fold(search)))
  const checked=items.filter(r=>selected.includes(r.id))
  const update=async(field:'lot'|'status')=>{
    try{
      if(!checked.length)throw new Error('Selecciona artículos.')
      if(field==='lot'&&!assign)throw new Error('Selecciona un lote.')
      if(field==='status'&&next==='comprado'&&checked.some(r=>r.data.status!=='pendiente'||missingVariants(r.data).length))throw new Error('Para marcar comprado, selecciona solo artículos pendientes con sus variantes completas.')
      if(!confirm('¿Aplicar a '+checked.length+' artículos?'))return
      await store.save({ops:checked.map(r=>operation('item',field==='lot'?{...r.data,lot:assign}:{...r.data,status:next},r)),uploads:[]})
      setSelected([]);setError('')
    }catch(e){setError(errorText(e))}
  }
  return <>
    <div className="page-head"><div><h1>Artículos</h1><p>{items.length} resultados</p></div><div className="actions"><Button onClick={()=>open('import')}><Clipboard size={17}/>Importar WhatsApp</Button><Button variant="primary" onClick={()=>open('item',client||undefined)}><Plus size={18}/>Nuevo artículo</Button></div></div>
    <div className="card filters"><label className="search"><Search size={18}/><input aria-label="Buscar artículos" placeholder="Buscar cliente, producto, enlace o variante" value={search} onChange={e=>setSearch(e.target.value)}/></label>
      <select aria-label="Filtrar por estado" value={status} onChange={e=>setStatus(e.target.value)}><option value="">Todos los estados</option>{Object.entries(labels).map(([id,label])=><option key={id} value={id}>{label}</option>)}</select>
      <select aria-label="Filtrar por lote" value={lot} onChange={e=>setLot(e.target.value)}><option value="">Todos los lotes</option>{lots.map(r=><option value={r.id} key={r.id}>{r.data.name}</option>)}</select>
      <input type="date" aria-label="Filtrar por fecha de registro" value={date} onChange={e=>setDate(e.target.value)}/>
      {client&&<Button onClick={clearClient}>Quitar filtro de {nameOf(client,clients)}</Button>}
    </div>
    {checked.length>0&&<div className="card filters">
      <strong>{checked.length} seleccionados</strong><Button onClick={()=>setSelected([])}>Limpiar selección</Button>
      <select aria-label="Lote para selección" value={assign} onChange={e=>setAssign(e.target.value)}><option value="">Elegir lote</option>{lots.map(r=><option value={r.id} key={r.id}>{r.data.name}</option>)}</select><Button onClick={()=>void update('lot')}>Asignar lote</Button>
      <select aria-label="Estado para selección" value={next} onChange={e=>setNext(e.target.value as Status)}>{(['comprado','en_transito','recibido','agotado'] as const).map(id=><option key={id} value={id}>{labels[id]}</option>)}</select><Button onClick={()=>void update('status')}>Cambiar estado</Button>{error&&<ErrorNote>{error}</ErrorNote>}
    </div>}
    {items.length===0?<Empty title="Sin artículos para esta búsqueda"/>:<div className="card-grid">{items.map(r=><ItemCard row={r} store={store} open={open} copy={copy} key={r.id} selected={selected.includes(r.id)} onSelect={store.role==='compras'?()=>setSelected(previous=>previous.includes(r.id)?previous.filter(id=>id!==r.id):[...previous,r.id]):undefined}/>)}</div>}
  </>
}
export function Customers({store,open,showItems}:{store:Store;open:Open;showItems:(id:string)=>void}) {
  const [search,setSearch]=useState('')
  const clients=byKind(store.rows,'client').filter(r=>fold([r.data.name,r.data.phone,r.data.notes].join(' ')).includes(fold(search)))
  const items=byKind(store.rows,'item')
  return <>
    <div className="page-head"><div><h1>Clientes</h1><p>Historial de pedidos, contactos y saldos.</p></div><Button variant="primary" onClick={()=>open('client')}><Plus size={18}/>Nuevo cliente</Button></div>
    <div className="card filters"><label className="search"><Search size={18}/><input aria-label="Buscar clientes" placeholder="Buscar por nombre o teléfono" value={search} onChange={e=>setSearch(e.target.value)}/></label></div>
    {clients.length===0?<Empty title="Sin clientes para mostrar"/>:<div className="card-grid">{clients.map(r=>{
      const orders=items.filter(p=>p.data.client===r.id)
      const balance=stats(store,[...orders,...byKind(store.rows,'item',true).filter(p=>p.data.client===r.id)],r.id).due
      return <article key={r.id} className="card item-card"><div className="card-top"><span className="initial">{r.data.name.slice(0,1).toUpperCase()}</span><div className="grow"><h3>{r.data.name}</h3><p className="muted small">{orders.length} artículos{r.data.phone?' · '+r.data.phone:''}</p></div><strong>{money(balance)}</strong></div>
        {r.data.notes&&<p className="muted wrap">{r.data.notes}</p>}
        <div className="actions"><Button onClick={()=>showItems(r.id)}>Ver pedidos</Button><Button onClick={()=>open('item',r.id)}>Añadir artículo</Button><Button onClick={()=>open('messages',r.id)}>Precios</Button><Button onClick={()=>open('client',r.id)}>Editar</Button><Button onClick={()=>open('history',r.id)}>Historial</Button>
        {store.role==='compras'&&<><Button onClick={()=>open('payment',r.id)}>Cobrar</Button><Button onClick={()=>open('merge',r.id)}>Fusionar</Button></>}</div>
      </article>
    })}</div>}
  </>
}
export function Buying({uid,store,open,copy}:{uid:string;store:Store;open:Open;copy:Copy}) {
  const items=byKind(store.rows,'item').filter(r=>r.data.status==='pendiente').sort((a,b)=>a.created_at.localeCompare(b.created_at)||a.id.localeCompare(b.id))
  const clients=byKind(store.rows,'client')
  const [id,setId]=useState(()=>localStorage.getItem(uid+'-purchase')??'')
  const [error,setError]=useState('')
  const [busy,setBusy]=useState(false)
  const current=items.find(r=>r.id===id)??items[0]
  const index=current?items.indexOf(current):-1
  const p=current?.data
  const change=async(status:Status)=>{
    if(!current||!p||busy)return
    if(status==='comprado'&&missingVariants(p).length){setError('Completa las variantes requeridas antes de comprar.');return}
    if(status==='comprado'&&!confirm('¿Confirmas que ya compraste este artículo en Temu?'))return
    setBusy(true);setError('')
    try{
      const ops=[operation('item',{...p,status},current)]
      if(status==='problema') {
        const notes=prompt('Describe el problema.')
        if(!notes?.trim())return
        ops.push(operation('incident',{item:current.id,status,notes:notes.trim(),files:[],date:today()}))
      }
      await store.save({ops,uploads:[]})
      setId(items[index+1]?.id??items[index-1]?.id??'')
    }catch(e){setError(errorText(e))}finally{setBusy(false)}
  }
  useEffect(()=>{if(current)localStorage.setItem(uid+'-purchase',current.id)},[uid,current?.id])
  return <>
    <div className="page-head"><div><h1>Preparar compra</h1><p>{items.length} artículos pendientes en Temu.</p></div><Button onClick={()=>open('item')} variant="primary"><Plus size={17}/>Nuevo artículo</Button></div>
    {p&&current?<><div className="card filters no-print">
      <Button onClick={()=>copy(purchaseList(items,clients))}><Clipboard size={16}/>Copiar lista de compra</Button>
      <Button onClick={()=>download('lista-de-compra.csv',csv([['Cliente','Producto','Cantidad','Variantes','URL','Notas'],...items.map(({data:r})=>[nameOf(r.client,clients),r.name,r.qty,r.variants.map(v=>v.label+': '+v.value).join(' · '),r.url,r.notes])]),'text/csv;charset=utf-8')}><ArrowDownToLine size={17}/>Exportar CSV</Button>
      <Button onClick={()=>window.print()}>Imprimir / Guardar PDF</Button>
    </div>
    <section className="card purchase no-print">
      <div className="card-top"><div className="grow"><p className="eyebrow">ARTÍCULO {index+1} DE {items.length}</p><h2>{p.name||'Artículo de Temu'}</h2><p className="muted">{nameOf(p.client,clients)}</p></div><Chip status={p.status}/></div>
      <progress value={index+1} max={items.length}/>
      <div className="photos">{p.files.map(path=><Photo key={path} path={path} uploads={store.queue.flatMap(b=>b.uploads)}/>)}</div>
      <pre>{specs(p)}</pre>
      {missingVariants(p).length>0&&<ErrorNote>Faltan: {missingVariants(p).join(', ')}</ErrorNote>}
      {error&&<ErrorNote>{error}</ErrorNote>}
      <div className="actions"><TemuLink url={p.url}/><Button onClick={()=>copy(p.url)}>Copiar URL</Button><Button onClick={()=>copy(specs(p))}>Copiar especificaciones</Button><Button onClick={()=>open('item',current.id)}>Editar ficha</Button></div>
      {store.role==='compras'&&<div className="actions"><Button disabled={busy} variant="primary" onClick={()=>void change('comprado')}>Marcar comprado</Button><Button disabled={busy} onClick={()=>void change('agotado')}>Marcar agotado</Button><Button disabled={busy} onClick={()=>void change('problema')}>Marcar problema</Button></div>}
      <div className="actions"><Button disabled={index<1} onClick={()=>setId(items[index-1].id)}>Anterior</Button><Button disabled={index>=items.length-1} onClick={()=>setId(items[index+1].id)}>Siguiente <ArrowRight size={16}/></Button></div>
    </section><pre className="print-only">{purchaseList(items,clients)}</pre></>:<Empty title="No hay compras pendientes"/>}
  </>
}
export function Packages({store,open,copy}:{store:Store;open:Open;copy:Copy}) {
  const [filter,setFilter]=useState('')
  const [onlyIssues,setOnlyIssues]=useState(false)
  const lots=byKind(store.rows,'lot')
  const items=byKind(store.rows,'item')
  const clients=byKind(store.rows,'client')
  const returns=byKind(store.rows,'refund')
  const rows=items.filter(r=>(!filter||r.data.lot===filter)&&(onlyIssues?issues.includes(r.data.status):purchased.includes(r.data.status)||issues.includes(r.data.status)))
  return <>
    <div className="page-head"><div><h1>Paquetes y revisión</h1><p>Seguimiento, cantidades recibidas e incidencias.</p></div>{store.role==='compras'&&<Button variant="primary" onClick={()=>open('lot')}><Plus size={18}/>Nuevo lote</Button>}</div>
    <div className="card-grid">{lots.map(r=>{
      const included=items.filter(p=>p.data.lot===r.id)
      const financial=totalsSafe(included,[],returns)
      return <article className="card item-card" key={r.id}><div className="card-top"><div className="grow"><h3>{r.data.name}</h3><p className="muted small">{r.data.date} · {lotLabels[r.data.status]}</p></div><Truck size={22}/></div>
      <p>{included.length} artículos · {new Set(included.map(p=>p.data.client)).size} clientes · {count(included,issues)} incidencias</p>
      {store.role==='compras'&&<p>Costo registrado: {money(financial.realCosts)}{financial.missingCosts?' · Faltan costos':''}</p>}
      {r.data.tracking&&<p className="muted">Seguimiento: {r.data.tracking}</p>}
      <div className="actions"><Button onClick={()=>setFilter(r.id)}>Ver artículos</Button>{store.role==='compras'&&<><Button onClick={()=>open('lot',r.id)}>Editar lote</Button><Button onClick={()=>open('history',r.id)}>Historial</Button></>}</div></article>
    })}</div>
    <div className="section-head"><h2>Revisión por artículo</h2><div className="actions">{filter&&<Button onClick={()=>setFilter('')}>Todos los lotes</Button>}<label className="check"><input type="checkbox" checked={onlyIssues} onChange={e=>setOnlyIssues(e.target.checked)}/>Solo incidencias</label></div></div>
    {rows.length===0?<Empty title="No hay artículos por revisar"/>:<div className="card-grid">{rows.map(r=><div key={r.id} className="stack"><ItemCard row={r} store={store} open={open} copy={copy}/><div className="card inline-card">Recibidas: {r.data.received??'Sin verificar'} / {r.data.qty} · {nameOf(r.data.client,clients)}{store.role==='compras'&&<Button onClick={()=>open('refund',r.id)}>Registrar reembolso</Button>}</div></div>)}</div>}
  </>
}
export function Billing({store,open,copy}:{store:Store;open:Open;copy:Copy}) {
  const clients=byKind(store.rows,'client')
  const items=byKind(store.rows,'item')
  const payments=byKind(store.rows,'payment')
  const refunds=byKind(store.rows,'refund')
  const [customer,setCustomer]=useState('')
  const [reportMonth,setReportMonth]=useState(today().slice(0,7))
  const selected=clients.find(r=>r.id===customer)
  const visible=customer?items.filter(r=>r.data.client===customer):items
  const paid=customer?payments.filter(r=>r.data.client===customer):payments
  const financialItems=[...visible,...byKind(store.rows,'item',true).filter(r=>!customer||r.data.client===customer)]
  const total=totalsSafe(financialItems,paid,refunds)
  return <>
    <div className="page-head"><div><h1>Cobros y precios</h1><p>Consulta importes y prepara mensajes por cliente.</p></div><Button variant="primary" onClick={()=>open('messages',customer||undefined)}><Clipboard size={17}/>Copiar todos los precios</Button></div>
    <div className="card filters"><select aria-label="Filtrar cobros por cliente" value={customer} onChange={e=>setCustomer(e.target.value)}><option value="">Todos los clientes</option>{clients.map(r=><option key={r.id} value={r.id}>{r.data.name}</option>)}</select>
    {store.role==='compras'&&selected&&<Button onClick={()=>open('payment',selected.id)}><CreditCard size={17}/>Registrar pago o anticipo</Button>}
    <Button onClick={()=>copy(priceList(visible,selected?[selected]:clients,paid,refunds,true))}>Copiar pendientes de pago</Button></div>
    <div className="metrics financial">{[['Vendido neto',total.netSales],['Cobrado',total.paid],['Saldo neto',total.due]].map(([label,value])=><div className="card metric" key={label}><strong>{money(Number(value))}</strong><span>{label}</span></div>)}</div>
    {store.role==='compras'&&<div className="card filters"><input aria-label="Mes del informe" type="month" value={reportMonth} onChange={e=>setReportMonth(e.target.value)}/><Button disabled={!reportMonth} onClick={()=>{
      const monthly=stats(store,financialItems.filter(r=>localDate(r.created_at).startsWith(reportMonth)),customer||undefined,reportMonth)
      download('resumen-'+reportMonth+'.csv',csv([['Mes','Cliente','Vendido neto USD','Cobrado USD','Saldo neto USD','Ganancia estimada USD','Ganancia de caja USD','Artículos sin costo'],[reportMonth,selected?.data.name??'Todos',monthly.netSales/100,monthly.paid/100,monthly.due/100,monthly.estimated/100,monthly.missingCosts?'':monthly.real/100,monthly.missingCosts]]),'text/csv;charset=utf-8')
    }}>Exportar resumen mensual</Button></div>}
    <div className="section-head"><h2>Artículos</h2></div>
    {visible.length?<div className="card-grid">{visible.map(r=><article className="card item-card" key={r.id}><h3>{r.data.name||'Artículo de Temu'}</h3><p>{nameOf(r.data.client,clients)} · {r.data.qty} unidades · {r.data.final===undefined?'Precio pendiente':money(r.data.final)+' por unidad'}</p><div className="actions">{store.role==='compras'&&<Button onClick={()=>open('price',r.id)}>Establecer precio</Button>}<Button onClick={()=>copy(priceList([r],clients,[],[]))}>Copiar precio</Button></div></article>)}</div>:<Empty title="Todavía no hay precios para mostrar"/>}
    <div className="section-head"><h2>Movimientos</h2></div>
    {paid.length||refunds.some(r=>visible.some(i=>i.id===r.data.item))?<div className="card recent">
      {[...paid].sort((a,b)=>b.data.date.localeCompare(a.data.date)).map(r=><div className="movement" key={r.id}><span>{r.data.date} · {nameOf(r.data.client,clients)} · {r.data.type}{r.data.notes?' · '+r.data.notes:''}</span><strong>{money(r.data.amount)}</strong>{store.role==='compras'&&<Button onClick={()=>open('history',r.id)}>Historial</Button>}</div>)}
      {refunds.filter(r=>visible.some(i=>i.id===r.data.item)).map(r=><div className="movement" key={r.id}><span>{r.data.date} · Reembolso {r.data.type} · {visible.find(i=>i.id===r.data.item)?.data.name||'Artículo'}</span><strong>{money(r.data.amount)}</strong>{store.role==='compras'&&<Button onClick={()=>open('history',r.id)}>Historial</Button>}</div>)}
    </div>:<Empty title="Sin movimientos registrados"/>}
  </>
}
export function MessagesDialog({store,id,close,copy}:{store:Store;id?:string;close:()=>void;copy:Copy}) {
  const [client,setClient]=useState(id??'')
  const [mode,setMode]=useState('all')
  const clients=byKind(store.rows,'client')
  const text=priceList(byKind(store.rows,'item'),clients.filter(r=>!client||r.id===client),byKind(store.rows,'payment'),byKind(store.rows,'refund'),mode==='pending',mode==='summary')
  return <Modal title="Precios para WhatsApp" onClose={close}><div className="stack"><div className="form-grid">
    <Field label="Cliente"><select value={client} onChange={e=>setClient(e.target.value)}><option value="">Todos los clientes</option>{clients.map(r=><option key={r.id} value={r.id}>{r.data.name}</option>)}</select></Field>
    <Field label="Formato"><select value={mode} onChange={e=>setMode(e.target.value)}><option value="all">Detalle de precios</option><option value="pending">Pendientes de pago</option><option value="summary">Resumen general</option></select></Field>
  </div><Message text={text} onCopy={copy}/></div></Modal>
}
export function ImportDialog({store,close,shared}:{store:Store;close:()=>void;shared:string}) {
  const [raw,setRaw]=useState(shared)
  const [candidates,setCandidates]=useState<Candidate[]>([])
  const [accepted,setAccepted]=useState<string[]>([])
  const s=useSubmit(store.save,close)
  const clients=byKind(store.rows,'client')
  const update=(key:string,patch:Partial<Candidate>)=>{setCandidates(rows=>rows.map(r=>r.key===key?{...r,...patch}:r));setAccepted(list=>list.filter(id=>id!==key))}
  return <Modal title="Importar desde WhatsApp" onClose={()=>{if(!raw||confirm('¿Cerrar sin guardar esta importación?'))close()}}>
    <form onSubmit={e=>{e.preventDefault();void s.submit(()=>{
      const ops:Op[]=[]
      const known=new Map(clients.map(r=>[fold(r.data.name),r.id]))
      if(!candidates.length||accepted.length!==candidates.length)throw new Error('Confirma cada artículo detectado.')
      for(const r of candidates){
        const name=r.clientName.trim()
        if(!name||name.length>160)throw new Error('Confirma el nombre de cada cliente.')
        const same=clients.filter(c=>fold(c.data.name)===fold(name))
        if(same.length>1)throw new Error('Hay más de un cliente llamado '+name+'. Registra su artículo eligiendo el cliente exacto.')
        let client=known.get(fold(name))
        if(!client){const next=operation('client',{name,phone:'',notes:''});ops.push(next);client=next.id;known.set(fold(name),client)}
        const data=cleanProduct({...blankItem,url:r.url,qty:Number(r.qty),variants:r.variants,notes:r.warnings.some(x=>x.startsWith('Texto')||x.includes('junto'))?r.source:''})
        ops.push(operation('item',{...blankItem,...data,client}))
      }
      return {ops,uploads:[]}
    })}}>
    <Field label="Mensaje original"><textarea rows={6} maxLength={24000} value={raw} onChange={e=>{setRaw(e.target.value);setCandidates([]);setAccepted([])}} placeholder={'María\nhttps://www.temu.com/…\nTalla: M\nColor: Negro\nCantidad: 1'}/></Field>
    <div className="actions"><Button onClick={()=>{setCandidates(parseMessage(raw));setAccepted([])}}>Detectar artículos</Button></div>
    {raw.trim()&&!candidates.length&&<p className="muted">Separa clientes con una línea en blanco o escribe «Cliente: nombre».</p>}
    {candidates.map((r,i)=><div className="card candidate" key={r.key}>
      <div className="card-top"><strong>Artículo {i+1}</strong><Button variant="plain" onClick={()=>{setCandidates(previous=>previous.filter(x=>x.key!==r.key));setAccepted(previous=>previous.filter(key=>key!==r.key))}}>Quitar</Button></div>
      <pre>{r.source}</pre>
      {(r.warnings.length>0||candidates.some(other=>other.key!==r.key&&other.url===r.url)||byKind(store.rows,'item').some(item=>item.data.url===r.url))&&<p className="notice">{r.warnings.join(' · ')}{r.url&&(candidates.some(other=>other.key!==r.key&&other.url===r.url)||byKind(store.rows,'item').some(item=>item.data.url===r.url))?' · Enlace repetido':''}</p>}
      <div className="form-grid"><Field label="Cliente"><input required value={r.clientName} onChange={e=>update(r.key,{clientName:e.target.value})}/></Field><Field label="Cantidad"><input type="number" required min="1" max="10000" value={r.qty} onChange={e=>update(r.key,{qty:e.target.value})}/></Field></div>
      <Field label="Enlace de Temu"><input required type="url" value={r.url} onChange={e=>update(r.key,{url:e.target.value})}/></Field>
      {r.variants.map((v,index)=><div className="variant-row" key={index}><input aria-label="Variante" required value={v.label} onChange={e=>update(r.key,{variants:r.variants.map((x,j)=>j===index?{...x,label:e.target.value}:x)})}/><input aria-label="Valor" required value={v.value} onChange={e=>update(r.key,{variants:r.variants.map((x,j)=>j===index?{...x,value:e.target.value}:x)})}/><Button onClick={()=>update(r.key,{variants:r.variants.filter((_,j)=>j!==index)})}>Quitar</Button></div>)}
      <Button onClick={()=>update(r.key,{variants:[...r.variants,{label:'',value:''}]})}><Plus size={15}/>Añadir variante</Button>
      <label className="check"><input type="checkbox" required checked={accepted.includes(r.key)} onChange={e=>setAccepted(previous=>e.target.checked?[...previous,r.key]:previous.filter(id=>id!==r.key))}/>Confirmo los datos y el cliente</label>
    </div>)}
    {candidates.length>0&&<SaveBar {...s} text={'Guardar '+candidates.length+' artículos'}/>}
    </form>
  </Modal>
}
export function HistoryDialog({store,row,close}:{store:Store;row:Row;close:()=>void}) {
  const [history,setHistory]=useState<{id:number;actor:string;at:string;before_value?:Row;after_value:Row}[]>([])
  const [error,setError]=useState('')
  const [loading,setLoading]=useState(true)
  useEffect(()=>{
    let active=true
    void api?.from('activity').select('id,actor,at,before_value,after_value').eq('record_id',row.id).order('id',{ascending:false}).limit(100).then(({data,error})=>{
      if(!active)return
      if(error)setError('No se pudo consultar la auditoría. '+error.message)
      else setHistory(data??[])
      setLoading(false)
    })
    return ()=>{active=false}
  },[row.id])
  const incidents=byKind(store.rows,'incident').filter(r=>r.data.item===row.id)
  const archive=async()=>{
    if(!confirm(row.archived?'¿Restaurar este registro?':'¿Archivar este registro? Podrás restaurarlo.'))return
    try {await store.save({ops:[operation(row.kind,row.data,row,!row.archived)],uploads:[]});close()}catch(e){setError(errorText(e))}
  }
  return <Modal title="Historial del registro" onClose={close}><div className="stack">
    <p className="muted small wrap">ID {row.id}</p>
    {error&&<ErrorNote>{error}</ErrorNote>}{loading&&<p>Cargando historial…</p>}
    {incidents.map(r=><article className="card candidate" key={r.id}><strong>{r.data.date} · {labels[r.data.status]}</strong><p className="wrap">{r.data.notes}</p><div className="photos">{r.data.files.map(path=><Photo path={path} key={path} uploads={store.queue.flatMap(b=>b.uploads)}/>)}</div></article>)}
    {history.map(h=><details className="card candidate" key={h.id}><summary>{new Date(h.at).toLocaleString('es-SV',{timeZone:'America/El_Salvador'})} · {h.before_value?'Versión '+h.after_value.version:'Creación'}{h.after_value.archived?' · Archivado':''}</summary><p className="muted small wrap">Cuenta {h.actor}</p><pre>{JSON.stringify({antes:h.before_value?.data??null,después:h.after_value.data},null,2)}</pre></details>)}
    {store.role==='compras'&&row.kind!=='settings'&&<div className="actions"><Button variant={row.archived?'primary':'danger'} onClick={()=>void archive()}>{row.archived?'Restaurar':'Archivar registro'}</Button></div>}
  </div></Modal>
}
export function MergeDialog({store,source,close}:{store:Store;source:Row<'client'>;close:()=>void}) {
  const [target,setTarget]=useState('')
  const s=useSubmit(store.save,close)
  const clients=byKind(store.rows,'client').filter(r=>r.id!==source.id)
  return <Modal title={'Fusionar '+source.data.name} onClose={close}><form onSubmit={e=>{e.preventDefault();void s.submit(()=>{
    const destination=clients.find(r=>r.id===target)
    if(!destination)throw new Error('Selecciona el cliente que conservarás.')
    if(!confirm('¿Trasladar los pedidos y pagos a '+destination.data.name+'?'))throw new Error('Fusión cancelada.')
    const notes=[destination.data.notes,source.data.notes].filter(Boolean).join('\n')
    if(notes.length>3000)throw new Error('Acorta las notas de los clientes antes de fusionar.')
    return {ops:[operation('client',{...destination.data,phone:destination.data.phone||source.data.phone,notes},destination),
      ...byKind(store.rows,'item').filter(r=>r.data.client===source.id).map(r=>operation('item',{...r.data,client:target},r)),
      ...byKind(store.rows,'payment').filter(r=>r.data.client===source.id).map(r=>operation('payment',{...r.data,client:target},r)),
      operation('client',source.data,source,true)],uploads:[]}
  })}}>
    <Field label="Cliente que se conservará"><select required value={target} onChange={e=>setTarget(e.target.value)}><option value="">Seleccionar</option>{clients.map(r=><option key={r.id} value={r.id}>{r.data.name}</option>)}</select></Field>
    <p className="muted">Los artículos activos y pagos pasarán al cliente seleccionado. La ficha original quedará archivada.</p><SaveBar {...s} text="Fusionar registros"/>
  </form></Modal>
}
export function Preferences({store,open}:{store:Store;open:Open}) {
  const archived=store.rows.filter(r=>r.archived)
  const [error,setError]=useState('')
  const [saving,setSaving]=useState(false)
  const settings=byKind(store.rows,'settings')[0]?.data
  const clients=byKind(store.rows,'client')
  const [template,setTemplate]=useState('')
  async function backup(){
    if(!api||!navigator.onLine){setError('Conéctate a internet para exportar.');return}
    setSaving(true);setError('')
    try {
      const {data,error}=await api.rpc('export_backup')
      if(error)throw error
      download('pedidos-respaldo-'+today()+'.json',JSON.stringify(data,null,2),'application/json')
    }catch(e){setError(errorText(e))}finally{setSaving(false)}
  }
  const kinds:Partial<Record<Kind,string>>={client:'Cliente',item:'Artículo',lot:'Lote',payment:'Pago',refund:'Reembolso',incident:'Incidencia',template:'Plantilla'}
  return <div className="stack">
    <div className="page-head"><div><h1>Ajustes</h1><p>{store.role==='compras'?'Administración de compras':'Administración de pedidos'}</p></div></div>
    {store.role==='compras'&&<section className="card purchase"><h2>Reglas de precios</h2><p>Ropa {money(settings?.clothing??150)} · Otros {money(settings?.other??100)} · Múltiplo {money(settings?.rounding??1)}</p><div className="actions"><Button onClick={()=>open('settings',settingsId)}>Editar reglas</Button></div></section>}
    <section className="card purchase"><h2>Plantillas de artículos</h2><div className="actions">
      <select aria-label="Artículo para plantilla" value={template} onChange={e=>setTemplate(e.target.value)}><option value="">Elegir un artículo</option>{byKind(store.rows,'item').map(r=><option key={r.id} value={r.id}>{r.data.name||r.data.url} · {nameOf(r.data.client,clients)}</option>)}</select>
      <Button disabled={!template} onClick={async()=>{
        try{
          const item=byKind(store.rows,'item').find(r=>r.id===template)
          if(!item)return
          const name=prompt('Nombre de la plantilla',item.data.name)?.trim()
          if(!name)return
          await store.save({ops:[operation('template',cleanProduct({...item.data,name}))],uploads:[]})
          setTemplate('');setError('')
        }catch(e){setError(errorText(e))}
      }}>Crear plantilla</Button></div>
      {byKind(store.rows,'template').map(r=><div className="movement" key={r.id}><span>{r.data.name}</span>{store.role==='compras'&&<Button onClick={()=>open('history',r.id)}>Historial</Button>}</div>)}
    </section>
    {store.role==='compras'&&<><section className="card purchase"><h2>Exportación y respaldo</h2><p>La copia JSON incluye registros y auditoría. Conserva también los adjuntos del almacenamiento privado de Supabase.</p><div className="actions">
      <Button disabled={saving||store.queue.length>0} onClick={()=>void backup()}><ArrowDownToLine size={16}/>{saving?'Exportando…':'Descargar respaldo JSON'}</Button>
      <Button onClick={()=>download('articulos-'+today()+'.csv',csv([['ID','Cliente','Artículo','URL','Cantidad','Estado','Precio unitario USD','Costo unitario USD','Variantes'],...byKind(store.rows,'item').map(r=>[r.id,nameOf(r.data.client,clients),r.data.name,r.data.url,r.data.qty,labels[r.data.status],r.data.final===undefined?'':r.data.final/100,r.data.cost===undefined?'':r.data.cost/100,r.data.variants.map(v=>v.label+': '+v.value).join(' · ')])]),'text/csv;charset=utf-8')}>Exportar artículos CSV</Button>
    </div>{store.queue.length>0&&<p className="muted">Sincroniza los cambios pendientes antes de crear la copia.</p>}</section>
    <section className="card purchase"><h2>Registros archivados</h2>{archived.length?archived.map(r=><div className="movement" key={r.id}><span>{kinds[r.kind]} · {'name' in r.data?r.data.name||r.id:r.id}</span><Button onClick={()=>open('history',r.id)}>Ver y restaurar</Button></div>):<p className="muted">No hay registros archivados.</p>}</section></>}
    {error&&<ErrorNote>{error}</ErrorNote>}
  </div>
}
