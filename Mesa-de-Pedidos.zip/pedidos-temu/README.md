# Mesa de Pedidos

PWA en español para registrar encargos de Temu y trabajar con dos cuentas. Usa dólares de Estados Unidos y fechas de El Salvador. La aplicación comienza vacía.

## Puesta en marcha

1. Crea un proyecto en Supabase. En **SQL Editor** ejecuta el archivo `supabase/migrations/202611130001_orders.sql` completo una sola vez.
2. En **Authentication → Users** crea las dos cuentas con sus correos y contraseñas individuales, y copia los UUID de cada cuenta. Elige **Create user** con confirmación de correo si ya comprobaste la titularidad de las direcciones. Desactiva el registro público y el inicio anónimo en la configuración de Auth. Mantén habilitado el proveedor de correo.
3. En **SQL Editor**, reemplaza los valores del siguiente ejemplo por los UUID reales y ejecútalo. El rol `compras` publica precios y administra cobros. El rol `pedidos` crea clientes y artículos y consulta precios y estados.

   ```sql
   insert into public.staff (user_id, role) values
     ('UUID-DE-ANGEL', 'compras'),
     ('UUID-DE-LA-ADMINISTRADORA', 'pedidos');
   ```

4. Copia `.env.example` a `.env.local` y configura la URL del proyecto y la clave **publishable**. Estos dos valores se incluyen en la compilación. Mantén las claves `service_role`, secretas, contraseñas y copias fuera del repositorio y del frontend.
5. Usa Node.js 24. Ejecuta `npm ci`, `npm test` y `npm run build`. Inicia `npm run preview` para probar la compilación en localhost. `npm run dev` sirve para desarrollo y omite el service worker.
6. Sube esta carpeta a un repositorio privado de GitHub. En Cloudflare **Workers & Pages**, crea una aplicación **Pages** con integración de GitHub. Configura rama `main`, compilación `npm run build`, salida `dist` y las dos variables `VITE_SUPABASE_…`. Si la carpeta está dentro de un repositorio más grande, elige `pedidos-temu` como directorio raíz. Configura `NODE_VERSION=24` si el constructor no toma `.node-version`.
7. Abre la URL HTTPS de Pages en Chrome para Android. Inicia sesión con cada cuenta en su teléfono. En el menú de Chrome usa **Instalar aplicación** o **Añadir a pantalla de inicio**. En navegadores compatibles, la PWA instalada aparece en el menú de compartir texto. También se puede pegar texto directamente en **Artículos → Importar WhatsApp**.
8. Antes de introducir datos reales, prueba con ambas cuentas un pedido, un precio, una recepción, una foto y una edición sin conexión. Archiva la prueba después.

Documentación oficial al 13 de noviembre de 2026. [Supabase Auth](https://supabase.com/docs/guides/auth/general-configuration) · [Cloudflare Pages y GitHub](https://developers.cloudflare.com/pages/get-started/git-integration/) · [Web Share Target](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Manifest/Reference/share_target)

## Trabajo diario

- **Pedidos.** Crea varios clientes dentro del formulario de artículo y utiliza «Seguir agregando artículos». Para importar texto, confirma cada nombre, cantidad y variante. Un enlace repetido puede pertenecer a otro cliente.
- **Compra.** Recorre la lista pendiente y marca cada compra después de confirmarla en Temu. Desde Artículos puedes seleccionar varios pedidos, asignarles un lote y actualizar su estado. Para regresar un artículo a pendiente, usa «Revisar» desde Artículos. El soporte público de Temu no documenta una integración oficial verificada para crear carritos compartidos ni preseleccionar variantes. La app utiliza los enlaces originales. [Soporte de Temu](https://www.temu.com/support/c3/temu-f-325-s-6341.html)
- **Precios.** Todos los campos de precio son unitarios. La sugerencia usa costo real si existe, o precio original, más comisión y gastos, menos descuento al cliente. El redondeo va hacia arriba al siguiente múltiplo configurado. El subtotal multiplica por cantidad. Las reglas iniciales son $1.50 para ropa y $1.00 para otros artículos. Modificarlas afecta precios que calcules después.
- **Cobros.** Los anticipos y pagos se registran por cliente, sin asignación a productos individuales. «Pendientes de pago» selecciona clientes con saldo positivo y muestra sus artículos cotizados. Si hay anticipos superiores a lo cotizado, el saldo neto puede quedar a favor. «Vendido neto» usa los precios publicados menos reembolsos al cliente. «Ganancia real de caja» resta los costos registrados de los artículos comprados y devoluciones al cliente, suma los reembolsos de Temu y parte de los cobros efectivamente recibidos. Cuando faltan costos, el panel lo indica. El panel mensual usa mes de registro para artículos y fecha del movimiento para pagos y reembolsos. Es un resumen operativo, sin conciliación contable por artículo.
- **Paquetes.** El lote conserva seguimiento y estado propio. La ficha individual registra cantidad recibida, problema, pruebas y entrega. Los reembolsos son movimientos separados de cambiar un estado.
- **Archivo.** El historial permite archivar y restaurar. Los artículos archivados salen de las listas de trabajo y se conservan en los totales financieros. El resumen para compartir por WhatsApp se genera con artículos activos. Archiva un movimiento de caja solo para corregirlo, pues deja de contar en el saldo.
- **PDF.** En Preparar compra, el botón «Imprimir / Guardar PDF» abre el diálogo de impresión con la lista completa. Elige «Guardar como PDF» en Android o en escritorio.

## Trabajo sin conexión

La primera sesión y sincronización requieren internet. Luego se pueden consultar datos locales y guardar operaciones incluso tras recargar la PWA. La cola se intenta sincronizar al reconectar, al volver a la app y cada 12 segundos en primer plano. Las fotos nuevas esperan junto con su registro. Las fotos remotas requieren conexión. Los borradores de formularios de artículo se guardan en la sesión de la pestaña, excepto archivos aún sin confirmar.

Si dos dispositivos cambian el mismo registro, la app conserva la cola y muestra los datos locales y del servidor. Usa esa comparación para copiar tus cambios, descarta la cola cuando hayas anotado lo que necesitas y vuelve a aplicar los datos a la versión actual. Este flujo requiere decisión manual. La app permite consultar datos de la cuenta en ese dispositivo hasta siete días desde su última autorización en línea. Usa bloqueo de pantalla y cierra sesión tras sincronizar en dispositivos compartidos.

## Copias y recuperación

1. En **Ajustes** sincroniza primero y descarga el respaldo JSON. Conserva copias periódicas en almacenamiento privado y cifrado.
2. Descarga por separado el contenido de `pedido-fotos` desde Storage o con su interfaz S3. Conserva los nombres y rutas de los objetos. Las claves S3 son exclusivas de administración. [Descarga de archivos](https://supabase.com/docs/guides/storage/management/download-objects)
3. Para recuperar, aplica la migración en un proyecto Supabase nuevo, crea las cuentas, asigna sus roles y ejecuta `python3 scripts/restore.py respaldo.json restaurar.sql`. Ejecuta el SQL generado en el proyecto vacío. La restauración se detiene si ya hay pedidos o auditoría. El script conserva UUID, versiones e historial y devuelve los recuentos por tipo. Elimina el SQL local cuando termines de restaurar.
4. Sube los objetos al bucket privado con las mismas rutas, prueba una foto y compara registros e importes antes de cambiar las variables de Pages y reconstruir. Los identificadores de auditoría de cuentas antiguas se conservan, aunque sus cuentas se hayan recreado.

Puedes llevar la base y los archivos a otro proyecto Supabase o a una instancia propia. Para un traslado completo de toda la plataforma, incluido Auth, utiliza las herramientas oficiales y respalda los archivos de Storage aparte.

## Costos, límites y mantenimiento

| Servicio | Plan gratuito consultado | Implicación |
| --- | --- | --- |
| Supabase | 500 MB de base, 1 GB de archivos, 5 GB de transferencia y 5 GB de transferencia en caché. Dos proyectos activos. Pausa por baja actividad durante una semana. | Descarga tus copias. El plan Free carece de respaldos automáticos incluidos. |
| Cloudflare Pages | 500 compilaciones al mes, 20,000 archivos por sitio y 25 MiB por archivo estático. | Las fotos privadas van en Supabase, separadas de la compilación. |
| GitHub Free | Repositorios privados. Límite de 100 MiB por archivo normal. | Guarda el código y las migraciones. Deja los datos de clientes y respaldos fuera del repositorio. |

[Precios Supabase](https://supabase.com/pricing) · [Pausa de proyectos](https://supabase.com/docs/guides/platform/free-project-pausing) · [Límites de Pages](https://developers.cloudflare.com/pages/platform/limits/) · [Planes de GitHub](https://docs.github.com/en/get-started/learning-about-github/githubs-plans) · [Límites de GitHub](https://docs.github.com/en/repositories/creating-and-managing-repositories/repository-limits)

`npm test` comprueba cálculos y reglas de PostgreSQL mediante PGlite. `npm run test:browser` usa Chromium y una pasarela local de prueba para simular dos dispositivos con la migración real. Configura `CHROMIUM_PATH` si Chromium está en otra ruta. Las pruebas locales no sustituyen verificar Supabase Auth, Storage e instalación Android con el dominio definitivo.

La primera versión exporta CSV y permite importar mensajes de WhatsApp. La importación CSV, los recordatorios programados y la conciliación de pagos por artículo quedan para una versión posterior. El seguimiento automático de Temu y el envío automático de WhatsApp están fuera del flujo.
