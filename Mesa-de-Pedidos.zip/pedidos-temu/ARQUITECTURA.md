# Arquitectura y flujos

La PWA estática en Cloudflare Pages usa React, TypeScript y Supabase Auth con cuentas aprovisionadas por el dueño. PostgreSQL es la fuente de verdad. La aplicación contiene un solo negocio, con dos perfiles de acceso; los clientes son contactos, sin cuentas. El servicio de trabajo sin conexión guarda una instantánea y una cola por cuenta en IndexedDB. El service worker solo guarda recursos estáticos.

## Datos

- Clientes → artículos solicitados, pagos y anticipos.
- Lotes → artículos asignados; cada artículo pertenece a un cliente y opcionalmente a un lote. El identificador de cada artículo permanece estable.
- Artículos → variantes, precio unitario en centavos, revisión e incidencias, reembolsos y adjuntos privados.
- Ajustes → comisión por categoría, excepción por cliente y redondeo.
- Operaciones → versión esperada, clave de idempotencia y auditoría de antes/después. La base valida relaciones y los campos que puede editar cada rol. Las transacciones se aplican completas.

## Flujos

1. Crear o seleccionar un cliente → guardar enlace, cantidad y variantes, o revisar la importación de WhatsApp antes de confirmar.
2. Preparar compra → cotejar variantes → abrir URL original → confirmar compra → asignar lote y seguimiento.
3. Calcular precio unitario y confirmar → publicar por sincronización → copiar resumen de WhatsApp → registrar cobros.
4. Revisar recibidos, comparando cantidad y variantes → guardar incidencia y evidencia → registrar devoluciones/reembolsos → confirmar entrega.
5. Exportar copia de datos y conservar adjuntos por separado. Restaurar primero en un proyecto nuevo y validar el recuento y referencias antes de usarlo como producción.

La sincronización se realiza al recuperar conexión, enfocar la app y periódicamente en primer plano. Ante una versión diferente, la cola se detiene para que el usuario compare y decida. Los cambios de compra no automatizan Temu.
